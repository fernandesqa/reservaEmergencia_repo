﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class TelaAlterarAplicacao : Form
    {
        //Declaração de variáveis e objetos
        Label[] label = new Label[5];
        ComboBoxMes comboBoxMes;
        ComboBoxAno comboBoxAno;
        ComboBoxTipoAplicacao comboBoxAplicacao;
        TextBoxMoeda textBoxMoeda;
        Button[] button = new Button[2];
        ConsultaBanco banco = new ConsultaBanco();
        Value format = new Value();
        Double dbTotal;
        String strUserSession;

        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public void InitializeTelaAlterarAplicacao(String strUserSession)
        {
            //Carrega a variável com o login do usuário logado
            this.strUserSession = strUserSession;

            //LABEL
            label[0] = new Label();
            label[0].Name = "lblAlterarAplicacoes";
            label[0].Text = "Alterar Aplicações";
            label[0].Font = new Font(label[0].Name, 18, FontStyle.Bold);
            label[0].SetBounds(5, 5, 350, 50);

            label[1] = new Label();
            label[1].Name = "lblMes";
            label[1].Text = "Mês";
            label[1].Font = new Font(label[1].Name, 12);
            label[1].SetBounds(5, 110, 50, 20);

            label[2] = new Label();
            label[2].Name = "lblAno";
            label[2].Text = "Ano";
            label[2].Font = new Font(label[2].Name, 12);
            label[2].SetBounds(345, 110, 50, 20);

            label[3] = new Label();
            label[3].Name = "lblTipoAplicacao";
            label[3].Text = "Tipo de Aplicação";
            label[3].Font = new Font(label[2].Name, 12);
            label[3].SetBounds(5, 150, 145, 20);

            label[4] = new Label();
            label[4].Name = "lblValor";
            label[4].Text = "Valor";
            label[4].Font = new Font(label[3].Name, 12);
            label[4].SetBounds(5, 190, 70, 20);

            //COMBOBOX
            comboBoxMes = new ComboBoxMes();
            comboBoxMes.InitializeComboBoxMes();
            comboBoxMes.SetBounds(150, 105, 150, 80);

            comboBoxAno = new ComboBoxAno();
            comboBoxAno.Name = "cboAno";
            comboBoxAno.InitializeComboBoxAno();
            comboBoxAno.SetBounds(415, 105, 150, 80);

            comboBoxAplicacao = new ComboBoxTipoAplicacao();
            comboBoxAplicacao.InitializeComboBoxTipoAplicacao();
            comboBoxAplicacao.SetBounds(150, 145, 150, 80);

            //TEXTBOX
            textBoxMoeda = new TextBoxMoeda();
            textBoxMoeda.InitializeTextBox(textBoxMoeda);
            textBoxMoeda.ReadOnly = true;
            textBoxMoeda.KeyPress += new KeyPressEventHandler(textMoeda_KeyPress);
            textBoxMoeda.SetBounds(150, 185, 120, 80);

            //BUTTON
            button[0] = new Button();
            button[0].Name = "btnBuscar";
            button[0].Text = "Buscar";
            button[0].SetBounds(585, 103, 100, 25);
            button[0].Click += new EventHandler(btnBuscar_Click);

            button[1] = new Button();
            button[1].Name = "btnAlterar";
            button[1].Text = "Alterar";
            button[1].Enabled = false;
            button[1].SetBounds(585, 300, 100, 40);
            button[1].Click += new EventHandler(btnAlterar_Click);

            //PANEL
            Panel pnlAlterarAplicacao = new Panel();
            pnlAlterarAplicacao.BorderStyle = BorderStyle.FixedSingle;
            pnlAlterarAplicacao.SetBounds(5, 5, 735, 400);
            pnlAlterarAplicacao.Controls.Add(label[0]);
            pnlAlterarAplicacao.Controls.Add(label[1]);
            pnlAlterarAplicacao.Controls.Add(label[2]);
            pnlAlterarAplicacao.Controls.Add(label[3]);
            pnlAlterarAplicacao.Controls.Add(label[4]);
            pnlAlterarAplicacao.Controls.Add(comboBoxMes);
            pnlAlterarAplicacao.Controls.Add(comboBoxAno);
            pnlAlterarAplicacao.Controls.Add(comboBoxAplicacao);
            pnlAlterarAplicacao.Controls.Add(textBoxMoeda);
            pnlAlterarAplicacao.Controls.Add(button[0]);
            pnlAlterarAplicacao.Controls.Add(button[1]);

            this.Text = "Alteração de Aplicações Financeiras";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Width = 765;
            this.Height = 450;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Controls.Add(pnlAlterarAplicacao);
        }

        public void textMoeda_KeyPress(Object sender, KeyPressEventArgs e)
        {
            if (button[0].Enabled)
            {
                button[1].Enabled = true;
            }
        }

        public void btnBuscar_Click(Object sender, EventArgs e)
        {
            strSql = "SELECT valor FROM APLICACOES_FINANCEIRAS_TB WHERE usuario = @Usuario AND id_mes = @idMes AND id_ano = @idAno AND id_aplicacao = @idAplicacao";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;
            cmd.Parameters.Add("@idMes", SqlDbType.Int).Value = Convert.ToInt32(banco.GetMonthId(comboBoxMes.Text));
            cmd.Parameters.Add("@idAno", SqlDbType.Int).Value = Convert.ToInt32(banco.GetYearId(comboBoxAno.Text));
            cmd.Parameters.Add("@idAplicacao", SqlDbType.Int).Value = Convert.ToInt32(banco.GetIdAplicacao(comboBoxAplicacao.Text));

            if (comboBoxMes.Text.ToLower().Equals("selecione") || comboBoxAno.Text.ToLower().Equals("selecione") || comboBoxAplicacao.Text.ToLower().Equals("selecione"))
            {
                MessageBox.Show("É necessário preencher o mês, o ano e a aplicação!", "Dados não selecionados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                try
                {
                    sqlCon.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    textBoxMoeda.Text = Convert.ToString(dr["valor"]);
                    dr.Close();

                    textBoxMoeda.ReadOnly = false;
                    comboBoxMes.Enabled = false;
                    comboBoxAno.Enabled = false;
                    comboBoxAplicacao.Enabled = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Aplicação não cadastrada no período informado!", "Dado não encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                finally
                {
                    sqlCon.Close();
                }
            }
        }

        public void btnAlterar_Click(Object sender, EventArgs e)
        {
            strSql = "UPDATE APLICACOES_FINANCEIRAS_TB SET valor = @Valor WHERE usuario = @Usuario AND id_mes = @idMes AND id_ano = @idAno AND id_aplicacao = @idAplicacao";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            Value format = new Value();
            cmd.Parameters.Add("@Valor", SqlDbType.VarChar).Value = format.returnValue(textBoxMoeda.Text.Replace(',', '.').Substring(3));
            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;
            cmd.Parameters.Add("@idMes", SqlDbType.Int).Value = Convert.ToInt32(banco.GetMonthId(comboBoxMes.Text));
            cmd.Parameters.Add("@idAno", SqlDbType.Int).Value = Convert.ToInt32(banco.GetYearId(comboBoxAno.Text));
            cmd.Parameters.Add("@idAplicacao", SqlDbType.Int).Value = Convert.ToInt32(banco.GetIdAplicacao(comboBoxAplicacao.Text));

            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Valor aplicado, alterado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                totalAplicado();

                textBoxMoeda.ReadOnly = true;
                comboBoxMes.Enabled = true;
                comboBoxAno.Enabled = true;
                comboBoxAplicacao.Enabled = true;
                button[1].Enabled = false;
                textBoxMoeda.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void totalAplicado()
        {
            strSql = "SELECT valor FROM APLICACOES_FINANCEIRAS_TB WHERE usuario ='" + strUserSession + "' AND id_aplicacao =" + banco.GetIdAplicacao(comboBoxAplicacao.Text) + "";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            try
            {
                
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    dbTotal += Convert.ToDouble(dr["valor"]);
                }
                updateTotal(Convert.ToString(dbTotal));
                dr.Close();
                dbTotal = 0.00; 
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void updateTotal(String dbValor)
        {
            strSql = "UPDATE TOTAL_APLICADO_TB SET total = @Total WHERE usuario = @Usuario AND id_aplicacao = @idAplicacao";
            sqlCon = new SqlConnection(strCon);
            SqlCommand update = new SqlCommand(strSql, sqlCon);

            update.Parameters.Add("@Total", SqlDbType.VarChar).Value = dbValor;
            update.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;
            update.Parameters.Add("@idAplicacao", SqlDbType.Int).Value = Convert.ToInt32(banco.GetIdAplicacao(comboBoxAplicacao.Text));

            try
            {
                sqlCon.Open();
                update.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }
    }
}
