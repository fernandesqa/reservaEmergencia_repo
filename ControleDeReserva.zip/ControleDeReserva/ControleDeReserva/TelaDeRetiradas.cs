﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class TelaDeRetiradas : Form
    {
        //Declaração de variáveis e objetos
        Label[] label = new Label[3];
        ComboBoxTipoAplicacao comboBoxTipoAplicacao = new ComboBoxTipoAplicacao();
        TextBoxMoeda txtValor = new TextBoxMoeda();
        ConsultaBanco banco = new ConsultaBanco();
        Value format = new Value();
        String strUserSession;
        Double dbTotal = 0.00;

        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public void InitializeRetiradas(String strUserSession)
        {
            //Carrega a variável com o login do usuário logado
            this.strUserSession = strUserSession;

            //LABEL
            label[0] = new Label();
            label[0].Name = "lblRetiradas";
            label[0].Text = "Registro de saque de valores da reserva";
            label[0].Font = new Font(label[0].Name, 18, FontStyle.Bold);
            label[0].SetBounds(5, 5, 500, 50);

            label[1] = new Label();
            label[1].Name = "lblValor";
            label[1].Text = "Valor retirado";
            label[1].Font = new Font(label[1].Name, 14);
            label[1].SetBounds(5, 145, 120, 40);

            label[2] = new Label();
            label[2].Name = "lblAplicação";
            label[2].Text = "Aplicação";
            label[2].Font = new Font(label[2].Name, 14);
            label[2].SetBounds(5, 95, 120, 40);

            //COMBOBOX
            comboBoxTipoAplicacao.InitializeComboBoxTipoAplicacao();
            comboBoxTipoAplicacao.SetBounds(145, 95, 120, 40);

            //TEXTBOX
            txtValor.InitializeTextBox(txtValor);
            txtValor.Font = new Font(txtValor.Name, 12);
            txtValor.SetBounds(145, 145, 120, 80);

            //BUTTON
            Button btnRegistrar = new Button();
            btnRegistrar.Name = "btnRegistrar";
            btnRegistrar.Text = "Registrar";
            btnRegistrar.SetBounds(145, 250, 120, 80);
            btnRegistrar.Click += new EventHandler(btnRegistrar_Click);

            //PANEL
            Panel pnlRetiradas = new Panel();
            pnlRetiradas.BorderStyle = BorderStyle.FixedSingle;
            pnlRetiradas.SetBounds(5, 5, 850, 440);
            pnlRetiradas.Controls.Add(label[0]);
            pnlRetiradas.Controls.Add(label[1]);
            pnlRetiradas.Controls.Add(label[2]);
            pnlRetiradas.Controls.Add(comboBoxTipoAplicacao);
            pnlRetiradas.Controls.Add(txtValor);
            pnlRetiradas.Controls.Add(btnRegistrar);

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Icon = new Icon(@"Imagens\iconeRetirada.ico");
            this.TopLevel = false;
            this.Text = "Retiradas";
            this.Width = 765;
            this.Height = 450;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.WindowState = FormWindowState.Maximized;
            this.Controls.Add(pnlRetiradas);
        }

        public void btnRegistrar_Click(Object sender, EventArgs e)
        {
            strSql = "SELECT total FROM TOTAL_APLICADO_TB WHERE usuario = @Usuario AND id_aplicacao = @idAplicacao";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;
            cmd.Parameters.Add("@idAplicacao", SqlDbType.Int).Value = Convert.ToInt32(banco.GetIdAplicacao(comboBoxTipoAplicacao.Text));

            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                dbTotal = Convert.ToDouble(dr["total"]);
                dr.Close();
                updateTotalAplicado();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não há registro de investimento com " + comboBoxTipoAplicacao.Text, "Registro não encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void updateTotalAplicado()
        {
            Double dbValor = Convert.ToDouble(format.returnValue(txtValor.Text.Substring(3)));
            Double dbNovoValor;
            strSql = "UPDATE TOTAL_APLICADO_TB SET total = @Total WHERE usuario = @Usuario AND id_aplicacao = @idAplicacao";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);
            dbNovoValor = dbTotal - dbValor;
            cmd.Parameters.Add("@Total", SqlDbType.VarChar).Value = dbNovoValor;
            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;
            cmd.Parameters.Add("@idAplicacao", SqlDbType.Int).Value = Convert.ToInt32(banco.GetIdAplicacao(comboBoxTipoAplicacao.Text));

            try
            {
                sqlCon.Open();
                if (dbValor <= dbTotal)
                {
                    cmd.ExecuteNonQuery();
                    setRegistro();
                }
                else
                {
                    MessageBox.Show("O valor informado é superior ao valor investido em " + comboBoxTipoAplicacao.Text, "Valor superior ao cadastrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void setRegistro()
        {
            strSql = "INSERT INTO RETIRADAS_TB VALUES (@Dia, @Mes, @Ano, @Horario, @Valor, @Usuario)";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);
            Datas ano = new Datas();
            

            cmd.Parameters.Add("@Dia", SqlDbType.VarChar).Value = ano.GetCurrentDay();
            cmd.Parameters.Add("@Mes", SqlDbType.VarChar).Value = ano.GetCurrentMonth();
            cmd.Parameters.Add("@Ano", SqlDbType.VarChar).Value = ano.GetCurrentYear();
            cmd.Parameters.Add("Horario", SqlDbType.VarChar).Value = ano.GetCurrentTime();
            cmd.Parameters.Add("@Valor", SqlDbType.VarChar).Value = format.returnValue(txtValor.Text.Replace(',', '.').Substring(3));
            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;

            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Saque registrado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }
    }
}
