﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class TelaDeDespesas : Form
    {
        //Declaração de variáveis e objetos
        private Label[] label = new Label[14];
        private TextBoxMoeda[] textBox = new TextBoxMoeda[12];
        private ComboBoxMes cbMes;
        ConsultaBanco banco = new ConsultaBanco();
        Value format = new Value();
        Datas data = new Datas();
        String strAno, strUserSession;
        Double dbTotal;

        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public void InitializeDespesas(String strUserSession)
        {
            //Carrega a variável com o login do usuario logado
            this.strUserSession = strUserSession;

            //LABELS
            label[0] = new Label();
            label[0].Name = "lblCadastroDespesas";
            label[0].Text = "Cadastro de Despesas";
            label[0].Font = new Font(label[0].Name, 18, FontStyle.Bold);
            label[0].SetBounds(5, 5, 300, 50);

            label[1] = new Label();
            label[1].Name = "lblMes";
            label[1].Text = "Mês";
            label[1].SetBounds(5, 60, 30, 20);

            label[2] = new Label();
            label[2].Name = "lblMoradia";
            label[2].Text = "Moradia";
            label[2].SetBounds(5, 100, 60, 20);

            label[3] = new Label();
            label[3].Name = "lblInternetTvFixo";
            label[3].Text = "Internet + Tv + Fixo";
            label[3].SetBounds(5, 140, 110, 20);

            label[4] = new Label();
            label[4].Name = "lblLuz";
            label[4].Text = "Luz";
            label[4].SetBounds(5, 180, 30, 20);

            label[5] = new Label();
            label[5].Name = "lblCartaoCredito";
            label[5].Text = "Cartão de Crédito";
            label[5].SetBounds(5, 220, 100, 20);

            label[6] = new Label();
            label[6].Name = "lblEducacao";
            label[6].Text = "Educação";
            label[6].SetBounds(5, 260, 60, 20);

            label[7] = new Label();
            label[7].Name = "lblSupermercado";
            label[7].Text = "Supermercado";
            label[7].SetBounds(5, 300, 100, 20);

            label[8] = new Label();
            label[8].Name = "lblLazer";
            label[8].Text = "Lazer";
            label[8].SetBounds(380, 100, 50, 20);

            label[9] = new Label();
            label[9].Name = "lblSaude";
            label[9].Text = "Saúde";
            label[9].SetBounds(380, 140, 50, 20);

            label[10] = new Label();
            label[10].Name = "lblContador";
            label[10].Text = "Contador";
            label[10].SetBounds(380, 180, 60, 20);

            label[11] = new Label();
            label[11].Name = "lblTransporte";
            label[11].Text = "Transporte";
            label[11].SetBounds(380, 220, 60, 20);

            label[12] = new Label();
            label[12].Name = "lblInss";
            label[12].Text = "INSS";
            label[12].SetBounds(380, 260, 40, 20);

            label[13] = new Label();
            label[13].Name = "lblOutros";
            label[13].Text = "Outros";
            label[13].SetBounds(380, 300, 60, 20);

            //COMBOBOX
            cbMes = new ComboBoxMes();
            cbMes.InitializeComboBoxMes();
            cbMes.SetBounds(50, 55, 150, 80);

            //TEXTBOX
            textBox[0] = new TextBoxMoeda();
            textBox[0].Name = "txtMoradia";
            textBox[0].InitializeTextBox(textBox[0]);
            textBox[0].SetBounds(115, 95, 120, 80);

            textBox[1] = new TextBoxMoeda();
            textBox[1].Name = "txtInternetTVFixo";
            textBox[1].InitializeTextBox(textBox[1]);
            textBox[1].SetBounds(115, 135, 120, 80);

            textBox[2] = new TextBoxMoeda();
            textBox[2].Name = "txtLuz";
            textBox[2].InitializeTextBox(textBox[2]);
            textBox[2].SetBounds(115, 170, 120, 80);

            textBox[3] = new TextBoxMoeda();
            textBox[3].Name = "txCartaoDeCredito";
            textBox[3].InitializeTextBox(textBox[3]);
            textBox[3].SetBounds(115, 215, 120, 80);

            textBox[4] = new TextBoxMoeda();
            textBox[4].Name = "txtEducacao";
            textBox[4].InitializeTextBox(textBox[4]);
            textBox[4].SetBounds(115, 255, 120, 80);

            textBox[5] = new TextBoxMoeda();
            textBox[5].Name = "txtSupermercado";
            textBox[5].InitializeTextBox(textBox[5]);
            textBox[5].SetBounds(115, 295, 120, 80);

            textBox[6] = new TextBoxMoeda();
            textBox[6].Name = "txtLazer";
            textBox[6].InitializeTextBox(textBox[6]);
            textBox[6].SetBounds(450, 95, 120, 80);

            textBox[7] = new TextBoxMoeda();
            textBox[7].Name = "txtSaude";
            textBox[7].InitializeTextBox(textBox[7]);
            textBox[7].SetBounds(450, 135, 120, 80);

            textBox[8] = new TextBoxMoeda();
            textBox[8].Name = "txtContador";
            textBox[8].InitializeTextBox(textBox[8]);
            textBox[8].SetBounds(450, 175, 120, 80);

            textBox[9] = new TextBoxMoeda();
            textBox[9].Name = "txtTransporte";
            textBox[9].InitializeTextBox(textBox[9]);
            textBox[9].SetBounds(450, 215, 120, 80);

            textBox[10] = new TextBoxMoeda();
            textBox[10].Name = "txtInss";
            textBox[10].InitializeTextBox(textBox[10]);
            textBox[10].SetBounds(450, 255, 120, 80);

            textBox[11] = new TextBoxMoeda();
            textBox[11].Name = "txtOutros";
            textBox[11].InitializeTextBox(textBox[11]);
            textBox[11].SetBounds(450, 295, 120, 80);

            //Button
            Button btnSalvar = new Button();
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Text = "Salvar";
            btnSalvar.SetBounds(470, 350, 100, 50);
            btnSalvar.Click += new EventHandler(btnSalvar_Click);

            //PANEL
            Panel pnlDespesas = new Panel();
            pnlDespesas.BorderStyle = BorderStyle.FixedSingle;
            pnlDespesas.SetBounds(5, 5, 850, 440);
            pnlDespesas.Controls.Add(label[0]);
            pnlDespesas.Controls.Add(label[1]);
            pnlDespesas.Controls.Add(label[2]);
            pnlDespesas.Controls.Add(label[3]);
            pnlDespesas.Controls.Add(label[4]);
            pnlDespesas.Controls.Add(label[5]);
            pnlDespesas.Controls.Add(label[6]);
            pnlDespesas.Controls.Add(label[7]);
            pnlDespesas.Controls.Add(label[8]);
            pnlDespesas.Controls.Add(label[9]);
            pnlDespesas.Controls.Add(label[10]);
            pnlDespesas.Controls.Add(label[11]);
            pnlDespesas.Controls.Add(label[12]);
            pnlDespesas.Controls.Add(label[13]);
            pnlDespesas.Controls.Add(cbMes);
            pnlDespesas.Controls.Add(textBox[0]);
            pnlDespesas.Controls.Add(textBox[1]);
            pnlDespesas.Controls.Add(textBox[2]);
            pnlDespesas.Controls.Add(textBox[3]);
            pnlDespesas.Controls.Add(textBox[4]);
            pnlDespesas.Controls.Add(textBox[5]);
            pnlDespesas.Controls.Add(textBox[6]);
            pnlDespesas.Controls.Add(textBox[7]);
            pnlDespesas.Controls.Add(textBox[8]);
            pnlDespesas.Controls.Add(textBox[9]);
            pnlDespesas.Controls.Add(textBox[10]);
            pnlDespesas.Controls.Add(textBox[11]);
            pnlDespesas.Controls.Add(btnSalvar);

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Icon = new Icon(@"Imagens\iconeDespesas.ico");
            this.TopLevel = false;
            this.Text = "Despesas";
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.WindowState = FormWindowState.Maximized;
            this.Controls.Add(pnlDespesas);
        }

        public void btnSalvar_Click(Object sender, EventArgs e)
        {
            //O código a seguir tenta inserir o ano atual na tabela Ano_TB
            String idAno;
            strAno = data.GetCurrentYear();
            strSql = "SELECT id_ano FROM ANO_TB WHERE ano = @Ano";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Ano", SqlDbType.VarChar).Value = strAno;

            try
            {
                sqlCon.Open();
                //Caso o ano já tenha sido cadastrado, o método GetYearId será chamado
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                idAno = Convert.ToString(dr["id_ano"]);
                dr.Close();
                inserirDadosDeDespesas(strUserSession, idAno);
            }
            catch (Exception ex)
            {
                //Caso o ano não esteja cadastrado na base de dados, o ano será cadastrado na base de dados
                banco.InsertYear(strAno);
                idAno = banco.GetYearId(strAno);
                inserirDadosDeDespesas(strUserSession, idAno);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void inserirDadosDeDespesas(String usuario, String idAno)
        {
            strSql = "INSERT INTO DESPESAS_TB (usuario, id_mes, id_ano, moradia, internetTvFixo, luz, cartaoDeCredito, educacao, supermercado, lazer, saude, contador, transporte, inss, outros) VALUES (@Usuario, @IdMes, @IdAno, @Moradia, @InternetTvFixo, @Luz, @CartaoDeCredito, @Educacao, @Supermercado, @Lazer, @Saude, @Contador, @Transporte, @Inss, @Outros)";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = usuario;
            cmd.Parameters.Add("@IdMes", SqlDbType.Int).Value = Convert.ToInt32(banco.GetMonthId(cbMes.Text));
            cmd.Parameters.Add("@IdAno", SqlDbType.Int).Value = Convert.ToInt32(idAno);
            cmd.Parameters.Add("@Moradia", SqlDbType.VarChar).Value = format.returnValue(textBox[0].Text.Replace(",", ".").Substring(3));
            cmd.Parameters.Add("@InternetTvFixo", SqlDbType.VarChar).Value = format.returnValue(textBox[1].Text.Replace(",", ".").Substring(3));
            cmd.Parameters.Add("@Luz", SqlDbType.VarChar).Value = format.returnValue(textBox[2].Text.Replace(",", ".").Substring(3));
            cmd.Parameters.Add("@CartaoDeCredito", SqlDbType.VarChar).Value = format.returnValue(textBox[3].Text.Replace(",", ".").Substring(3));
            cmd.Parameters.Add("@Educacao", SqlDbType.VarChar).Value = format.returnValue(textBox[4].Text.Replace(",", ".").Substring(3));
            cmd.Parameters.Add("@Supermercado", SqlDbType.VarChar).Value = format.returnValue(textBox[5].Text.Replace(",", ".").Substring(3));
            cmd.Parameters.Add("@Lazer", SqlDbType.VarChar).Value = format.returnValue(textBox[6].Text.Replace(",", ".").Substring(3));
            cmd.Parameters.Add("@Saude", SqlDbType.VarChar).Value = format.returnValue(textBox[7].Text.Replace(",", ".").Substring(3));
            cmd.Parameters.Add("@Contador", SqlDbType.VarChar).Value = format.returnValue(textBox[8].Text.Replace(",", ".").Substring(3));
            cmd.Parameters.Add("@Transporte", SqlDbType.VarChar).Value = format.returnValue(textBox[9].Text.Replace(",", ".").Substring(3));
            cmd.Parameters.Add("@Inss", SqlDbType.VarChar).Value = format.returnValue(textBox[10].Text.Replace(",", ".").Substring(3));
            cmd.Parameters.Add("@Outros", SqlDbType.VarChar).Value = format.returnValue(textBox[11].Text.Replace(",", ".").Substring(3));

            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Despesas de " + cbMes.Text + " de " + strAno + " Cadastradas com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                totalDespesas();
            }
            catch (Exception e)
            {
                MessageBox.Show("As despesas de " + cbMes.Text + " de " + strAno + " Já foram cadastradas", "Duplicidade de dados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        public void totalDespesas()
        {
            strSql = "SELECT moradia, internetTvFixo, luz, cartaoDeCredito, educacao, supermercado, lazer, saude, contador, transporte, inss, outros FROM DESPESAS_TB WHERE usuario = @Usuario AND id_mes = @idMes AND id_ano = @idAno";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;
            cmd.Parameters.Add("@idMes", SqlDbType.Int).Value = Convert.ToInt32(banco.GetMonthId(cbMes.Text));
            cmd.Parameters.Add("@idAno", SqlDbType.Int).Value = Convert.ToInt32(banco.GetYearId(data.GetCurrentYear()));
            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                
                int iTotColumns = dr.FieldCount;
          
                for (int i = 0; i < iTotColumns; i++)
                {
                    dbTotal += Convert.ToDouble(dr[i]);
                }

                int iTotCarac = dbTotal.ToString().Length;

                
                
                Boolean bContainsComa = false;

                for (int j = 0; j < iTotCarac; j++)
                {
                    if (dbTotal.ToString().Substring(j, 1).Equals(","))
                    {
                        bContainsComa = true;
                    }
                }

                if (bContainsComa)
                {
                    insertTotal(dbTotal.ToString().Replace(',', '.'));

                }
                else
                {
                    insertTotal(Convert.ToString(dbTotal));
                }
                dr.Close();
                dbTotal = 0.00;
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void insertTotal(String dbValor)
        {
            strSql = "INSERT INTO TOTAL_DESPESAS_TB VALUES(@Usuario, @idMes, @idAno, @Total)";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;
            cmd.Parameters.Add("@idMes", SqlDbType.Int).Value = Convert.ToInt32(banco.GetMonthId(cbMes.Text));
            cmd.Parameters.Add("@idAno", SqlDbType.Int).Value = Convert.ToInt32(banco.GetYearId(data.GetCurrentYear()));
            cmd.Parameters.Add("@Total", SqlDbType.VarChar).Value = dbValor;

            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }
    }
}
