﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class TextBoxMoeda : TextBox
    {
        String sDisplay;

        public void InitializeTextBox(TextBox txt)
        {
            txt.Text = "R$ 0,00";
            txt.MaxLength = 9;
            txt.Enter += TirarMascara;
            txt.KeyPress += EntradaDeValores;
            txt.Leave += RetornarMascara;
            

        }

        //Função para colocar a mascara
        private void RetornarMascara(Object sender, EventArgs e)
        {

            TextBox txt = (TextBox)sender;
            String getValores = txt.Text;
            String[] setValores;
            int iTotCaracter = txt.TextLength;

            String getText = txt.Text;
            if (getText == "")
            {
                txt.Text = sDisplay;
            }

            if (iTotCaracter == 1)
            {
                setValores = new String[4];
                setValores[0] = "0";
                setValores[1] = ",";
                setValores[2] = "0";
                setValores[3] = getValores[0].ToString();

                txt.Text = "R$ " + setValores[0].ToString() + setValores[1].ToString() + setValores[2] + setValores[3].ToString();

            }
            else if (iTotCaracter == 2)
            {
                setValores = new String[4];
                setValores[0] = "0";
                setValores[1] = ",";
                setValores[2] = getValores[0].ToString();
                setValores[3] = getValores[1].ToString();

                txt.Text = "R$ " + setValores[0].ToString() + setValores[1].ToString() + setValores[2] + setValores[3].ToString();
            }
            else if (iTotCaracter == 3)
            {
                setValores = new String[4];
                setValores[0] = getValores[0].ToString();
                setValores[1] = ",";
                setValores[2] = getValores[1].ToString();
                setValores[3] = getValores[2].ToString();

                txt.Text = "R$ " + setValores[0].ToString() + setValores[1].ToString() + setValores[2] + setValores[3].ToString();
            }
            else if (iTotCaracter == 4)
            {
                setValores = new String[5];
                setValores[0] = getValores[0].ToString();
                setValores[1] = getValores[1].ToString();
                setValores[2] = ",";
                setValores[3] = getValores[2].ToString();
                setValores[4] = getValores[3].ToString();

                txt.Text = "R$ " + setValores[0].ToString() + setValores[1].ToString() + setValores[2] + setValores[3].ToString() + setValores[4].ToString();
            }
            else if (iTotCaracter == 5)
            {
                setValores = new String[6];
                setValores[0] = getValores[0].ToString();
                setValores[1] = getValores[1].ToString();
                setValores[2] = getValores[2].ToString();
                setValores[3] = ",";
                setValores[4] = getValores[3].ToString();
                setValores[5] = getValores[4].ToString();

                txt.Text = "R$ " + setValores[0].ToString() + setValores[1].ToString() + setValores[2] + setValores[3].ToString() + setValores[4].ToString() + setValores[5].ToString();
            }
            else if (iTotCaracter == 6)
            {
                setValores = new String[8];
                setValores[0] = getValores[0].ToString();
                setValores[1] = ".";
                setValores[2] = getValores[1].ToString();
                setValores[3] = getValores[2].ToString();
                setValores[4] = getValores[3].ToString();
                setValores[5] = ",";
                setValores[6] = getValores[4].ToString();
                setValores[7] = getValores[5].ToString();

                txt.Text = "R$ " + setValores[0].ToString() + setValores[1].ToString() + setValores[2] + setValores[3].ToString() + setValores[4].ToString() + setValores[5].ToString() + setValores[6].ToString() + setValores[7].ToString();
            }
            else if (iTotCaracter == 7)
            {
                setValores = new String[9];
                setValores[0] = getValores[0].ToString();
                setValores[1] = getValores[1].ToString();
                setValores[2] = ".";
                setValores[3] = getValores[2].ToString();
                setValores[4] = getValores[3].ToString();
                setValores[5] = getValores[4].ToString();
                setValores[6] = ",";
                setValores[7] = getValores[5].ToString();
                setValores[8] = getValores[6].ToString();

                txt.Text = "R$ " + setValores[0].ToString() + setValores[1].ToString() + setValores[2] + setValores[3].ToString() + setValores[4].ToString() + setValores[5].ToString() + setValores[6].ToString() + setValores[7].ToString() + setValores[8].ToString();
            }
            else if (iTotCaracter == 8)
            {
                setValores = new String[10];
                setValores[0] = getValores[0].ToString();
                setValores[1] = getValores[1].ToString();
                setValores[2] = getValores[2].ToString();
                setValores[3] = ".";
                setValores[4] = getValores[3].ToString();
                setValores[5] = getValores[4].ToString();
                setValores[6] = getValores[5].ToString();
                setValores[7] = ",";
                setValores[8] = getValores[6].ToString();
                setValores[9] = getValores[7].ToString();

                txt.Text = "R$ " + setValores[0].ToString() + setValores[1].ToString() + setValores[2] + setValores[3].ToString() + setValores[4].ToString() + setValores[5].ToString() + setValores[6].ToString() + setValores[7].ToString() + setValores[8].ToString() + setValores[9].ToString();
            }
            else if (iTotCaracter == 9)
            {
                setValores = new String[12];
                setValores[0] = getValores[0].ToString();
                setValores[1] = ".";
                setValores[2] = getValores[1].ToString();
                setValores[3] = getValores[2].ToString();
                setValores[4] = getValores[3].ToString();
                setValores[5] = ".";
                setValores[6] = getValores[4].ToString();
                setValores[7] = getValores[5].ToString();
                setValores[8] = getValores[6].ToString();
                setValores[9] = ",";
                setValores[10] = getValores[7].ToString();
                setValores[11] = getValores[8].ToString();

                txt.Text = "R$ " + setValores[0].ToString() + setValores[1].ToString() + setValores[2] + setValores[3].ToString() + setValores[4].ToString() + setValores[5].ToString() + setValores[6].ToString() + setValores[7].ToString() + setValores[8].ToString() + setValores[9].ToString() + setValores[10].ToString() + setValores[11].ToString();
            }
        }

        //Função para retirar a mascara
        private void TirarMascara(Object sender, EventArgs e)
        {
            TextBox txt = (TextBox)sender;
            sDisplay = txt.Text;
            txt.Text = "";

        }

        //Função para permitir somente números
        private void EntradaDeValores(Object sender, KeyPressEventArgs e)
        {
           TextBox txt = (TextBox)sender;

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
