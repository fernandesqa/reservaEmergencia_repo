﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControleDeReserva
{
    public partial class Datas
    {
        public String GetCurrentYear()
        {
            DateTime ano = DateTime.Now;
            return ano.Year.ToString();
        }

        public String GetCurrentMonth()
        {
            DateTime mes = DateTime.Now;
            String strMes = "";
            if (mes.Month.ToString() == "1")
            {
                strMes = "Janeiro";
            }else if (mes.Month.ToString() == "2")
            {
                strMes = "Fevereiro";
            }
            else if (mes.Month.ToString() == "3")
            {
                strMes = "Março";
            }
            else if (mes.Month.ToString() == "4")
            {
                strMes = "Abril";
            }
            else if (mes.Month.ToString() == "5")
            {
                strMes = "Maio";
            }
            else if (mes.Month.ToString() == "6")
            {
                strMes = "Junho";
            }
            else if (mes.Month.ToString() == "7")
            {
                strMes = "Julho";
            }
            else if (mes.Month.ToString() == "8")
            {
                strMes = "Agosto";
            }
            else if (mes.Month.ToString() == "9")
            {
                strMes = "Setembro";
            }
            else if (mes.Month.ToString() == "10")
            {
                strMes = "Outubro";
            }
            else if (mes.Month.ToString() == "11")
            {
                strMes = "Novembro";
            }
            else if (mes.Month.ToString() == "12")
            {
                strMes = "Dezembro";
            }

            return strMes;
        }

        public String GetCurrentDay()
        {
            DateTime dia = DateTime.Now;
            return dia.Day.ToString();
        }

        public String GetCurrentTime()
        {
            String strHora;
            DateTime hora = DateTime.Now;
            strHora = hora.ToLocalTime().ToString();
            strHora = strHora.Split(' ')[1];
            return strHora;
        }
    }
}
