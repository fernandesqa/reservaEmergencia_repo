﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class TelaDePerfil : Form
    {
        //Declaração de variáveis e objetos
        private Label[] labels = new Label[6];
        private TextBox[] textBox = new TextBox[5];
        private Button[] button = new Button[2];
        String strUserSession;

        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public void InitializePerfil(String strUserSession)
        {
            //Carrega a variável com o login do usuário logado
            this.strUserSession = strUserSession;
            
            //LABELS
            labels[0] = new Label();
            labels[0].Name = "lblTitulo";
            labels[0].Text = "Perfil de Usuário";
            labels[0].Font = new Font(labels[0].Font.Name, 18, FontStyle.Bold); 
            labels[0].SetBounds(5, 5, 250, 50);

            labels[1] = new Label();
            labels[1].Name = "lblNome";
            labels[1].Text = "Nome";
            labels[1].Font = new Font(labels[1].Name, 12);
            labels[1].SetBounds(5, 100, 60, 20);

            labels[2] = new Label();
            labels[2].Name = "lblUsuario";
            labels[2].Text = "Usuário";
            labels[2].Font = new Font(labels[2].Name, 12);
            labels[2].SetBounds(5, 160, 80, 20);

            labels[3] = new Label();
            labels[3].Name = "lblTempoReserva";
            labels[3].Text = "Tempo de Reserva";
            labels[3].Font = new Font(labels[3].Name, 12);
            labels[3].SetBounds(5, 220, 150, 20);

            labels[4] = new Label();
            labels[4].Name = "lblPergunta";
            labels[4].Text = "Pergunta";
            labels[4].Font = new Font(labels[4].Name, 12);
            labels[4].SetBounds(5, 280, 150, 20);

            labels[5] = new Label();
            labels[5].Name = "lblResposta";
            labels[5].Text = "Resposta";
            labels[5].Font = new Font(labels[5].Name, 12);
            labels[5].SetBounds(5, 340, 150, 20);

            //TEXTBOXES
            textBox[0] = new TextBox();
            textBox[0].Name = "txtNome";
            textBox[0].ReadOnly = true;
            textBox[0].Enabled = false;
            textBox[0].Font = new Font(textBox[0].Name, 14);
            textBox[0].SetBounds(120, 95, 350, 180);

            textBox[1] = new TextBox();
            textBox[1].Name = "txtUsuario";
            textBox[1].ReadOnly = true;
            textBox[1].Enabled = false;
            textBox[1].Font = new Font(textBox[1].Name, 14);
            textBox[1].SetBounds(120, 155, 200, 180);

            textBox[2] = new TextBox();
            textBox[2].Name = "txtTempoDeReserva";
            textBox[2].ReadOnly = true;
            textBox[2].Enabled = false;
            textBox[2].Font = new Font(textBox[2].Name, 14);
            textBox[2].SetBounds(160, 220, 40, 180);

            textBox[3] = new TextBox();
            textBox[3].Name = "txtPergunta";
            textBox[3].ReadOnly = true;
            textBox[3].Enabled = false;
            textBox[3].Font = new Font(textBox[3].Name, 14);
            textBox[3].SetBounds(160, 275, 350, 180);

            textBox[4] = new TextBox();
            textBox[4].Name = "txtResposta";
            textBox[4].ReadOnly = true;
            textBox[4].Enabled = false;
            textBox[4].Font = new Font(textBox[4].Name, 14);
            textBox[4].SetBounds(160, 335, 350, 180);

            //BUTTONS
            button[0] = new Button();
            button[0].Name = "btnAlterarCadastro";
            button[0].Text = "Alterar Cadastro";
            button[0].SetBounds(550, 370, 90, 40);
            button[0].Click += new EventHandler(btnAlterarCadastro_Click);

            button[1] = new Button();
            button[1].Name = "btnAlterarSenha";
            button[1].Text = "Alterar Senha";
            button[1].SetBounds(650, 370, 90, 40);
            button[1].Click += new EventHandler(btnAlterarSenha_Click);

            //PANEL
            Panel pnlPerfil = new Panel();
            pnlPerfil.BorderStyle = BorderStyle.FixedSingle;
            pnlPerfil.SetBounds(5, 5, 850, 440);
            pnlPerfil.Controls.Add(labels[0]);
            pnlPerfil.Controls.Add(labels[1]);
            pnlPerfil.Controls.Add(labels[2]);
            pnlPerfil.Controls.Add(labels[3]);
            pnlPerfil.Controls.Add(labels[4]);
            pnlPerfil.Controls.Add(labels[5]);
            pnlPerfil.Controls.Add(textBox[0]);
            pnlPerfil.Controls.Add(textBox[1]);
            pnlPerfil.Controls.Add(textBox[2]);
            pnlPerfil.Controls.Add(textBox[3]);
            pnlPerfil.Controls.Add(textBox[4]);
            pnlPerfil.Controls.Add(button[0]);
            pnlPerfil.Controls.Add(button[1]);
            

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Icon = new Icon(@"Imagens\iconePerfil.ico");
            this.Text = "Cadastro de usuário";
            this.Width = 765;
            this.Height = 450;
            this.TopLevel = false;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.WindowState = FormWindowState.Maximized;
            this.Controls.Add(pnlPerfil);

            //Carrega os dados nos campos
            dadosUsuario_Load();
        }

        private void dadosUsuario_Load()
        {
            strSql = "SELECT nome, sobrenome, tempoReserva, pergunta, resposta FROM PESSOA_PERFIL_TB WHERE usuario = @Usuario";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;

            try
            {
                sqlCon.Open();
                
                SqlDataReader dr = cmd.ExecuteReader();

                dr.Read();

                textBox[0].Text = dr["nome"].ToString();
                textBox[1].Text = dr["sobrenome"].ToString();
                textBox[2].Text = dr["tempoReserva"].ToString();
                textBox[3].Text = dr["pergunta"].ToString();
                textBox[4].Text = dr["resposta"].ToString();

                dr.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        public void btnAlterarCadastro_Click(Object sender, System.EventArgs e)
        {
            var formAlterarCadastro = new TelaAlterarCadastro();
            formAlterarCadastro.InitializeAlterarCadastro(strUserSession);
            formAlterarCadastro.Show();
        }

        public void btnAlterarSenha_Click(Object sender, System.EventArgs e)
        {
            var formAlterarSenha = new TelaAlterarSenha();
            formAlterarSenha.InitializeTelaAlterarSenha(strUserSession);
            formAlterarSenha.Show();
        }
    }
}
