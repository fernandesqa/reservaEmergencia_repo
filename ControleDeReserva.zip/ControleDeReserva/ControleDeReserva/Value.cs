﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControleDeReserva
{
    class Value
    {
        public String returnValue(String strValor)
        {
            String strNewValue = "";

            if (strValor.Substring(0, 1).ToLower().Equals("r"))
            {
                
                strValor = strValor.Substring(3);
                strNewValue = formatValue(strValor);
                
            }

            strNewValue = formatValue(strValor);

            return strNewValue;
        }

        private String formatValue(String strValue)
        {
            String strAux, strCent, formatedValue;
            int iLength;
            strAux = strValue;
            formatedValue = "";

            iLength = strAux.Length - 3;
            strCent = strValue.Substring(iLength);
            
            for (int i = 0; i < iLength; i++)
            {
                if (!strAux.Substring(i, 1).Equals("."))
                {

                    formatedValue += strAux.Substring(i, 1);
                }

            }
            formatedValue += strCent;
            
            iLength = formatedValue.Length;

            if (iLength > 6)
            {
               
                iLength = formatedValue.Length - 1;
                formatedValue = "";
                strCent = strAux.Substring(iLength);
              
                for (int i = 0; i < iLength; i++)
                {
                    if (!strAux.Substring(i, 1).Equals("."))
                    {

                        formatedValue += strAux.Substring(i, 1);
                    }

                }
                formatedValue += ".";
                formatedValue += strCent;
            }
            return formatedValue;
        }
    }
}
