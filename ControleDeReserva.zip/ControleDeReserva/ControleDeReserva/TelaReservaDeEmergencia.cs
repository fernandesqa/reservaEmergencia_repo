﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class TelaReservaDeEmergencia : Form
    {
        //Declaração de varáveis e objetos
        Label[] label = new Label[5];
        TextBox[] textBox = new TextBox[4];
        String strUserSession;

        public void InitializeReservaDeEmergencia(String strUserSession)
        {
            //Carrga a variável com o login do usuário logado
            this.strUserSession = strUserSession;

            //LABEL
            label[0] = new Label();
            label[0].Name = "lblReserva";
            label[0].Text = "Reserva de Emergência";
            label[0].Font = new Font(label[0].Name, 18, FontStyle.Bold);
            label[0].SetBounds(5, 5, 350, 50);

            label[1] = new Label();
            label[1].Name = "lblMediaCusto";
            label[1].Text = "Média de custo de vida";
            label[1].Font = new Font(label[1].Name, 12);
            label[1].SetBounds(5, 110, 180, 20);

            label[2] = new Label();
            label[2].Name = "lblVlrTotalInvestido";
            label[2].Text = "Valor total investido";
            label[2].Font = new Font(label[2].Name, 12);
            label[2].SetBounds(5, 150, 180, 20);

            label[3] = new Label();
            label[3].Name = "lblMeta";
            label[3].Text = "Meta";
            label[3].Font = new Font(label[3].Name, 12);
            label[3].SetBounds(5, 190, 180, 20);

            label[4] = new Label();
            label[4].Name = "lblReservaPara";
            label[4].Text = "Você tem reserva para";
            label[4].Font = new Font(label[3].Name, 12);
            label[4].SetBounds(5, 230, 180, 20);

            CalculoReserva reserva = new CalculoReserva();

            //TEXTBOX
            textBox[0] = new TextBox();
            textBox[0].Name = "txtMediaCusto";
            textBox[0].ReadOnly = true;
            textBox[0].Text = reserva.media(strUserSession);
            textBox[0].SetBounds(190, 107, 120, 80);

            textBox[1] = new TextBox();
            textBox[1].Name = "txtVlrTotalInvestido";
            textBox[1].ReadOnly = true;
            textBox[1].Text = reserva.total(strUserSession);
            textBox[1].SetBounds(190, 147, 120, 80);

            textBox[2] = new TextBox();
            textBox[2].Name = "txtMeta";
            textBox[2].ReadOnly = true;
            textBox[2].Text = reserva.metaDaReserva(strUserSession);
            textBox[2].SetBounds(190, 187, 120, 80);

            textBox[3] = new TextBox();
            textBox[3].Name = "txtReservaPara";
            textBox[3].ReadOnly = true;
            textBox[3].Text = reserva.reservaAtual();
            textBox[3].SetBounds(190, 227, 120, 80);

            //PANEL
            Panel pnlReserva = new Panel();
            pnlReserva.BorderStyle = BorderStyle.FixedSingle;
            pnlReserva.SetBounds(5, 5, 850, 440);
            pnlReserva.Controls.Add(label[0]);
            pnlReserva.Controls.Add(label[1]);
            pnlReserva.Controls.Add(label[2]);
            pnlReserva.Controls.Add(label[3]);
            pnlReserva.Controls.Add(label[4]);
            pnlReserva.Controls.Add(textBox[0]);
            pnlReserva.Controls.Add(textBox[1]);
            pnlReserva.Controls.Add(textBox[2]);
            pnlReserva.Controls.Add(textBox[3]);

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Icon = new Icon(@"Imagens\iconeReserva.ico");
            this.Text = "Reserva de Emergência";
            this.TopLevel = false;
            this.Width = 765;
            this.Height = 450;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.WindowState = FormWindowState.Maximized;
            this.Controls.Add(pnlReserva);
        }
    }
}
