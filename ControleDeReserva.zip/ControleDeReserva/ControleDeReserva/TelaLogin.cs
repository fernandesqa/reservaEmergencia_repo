﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{

   public partial class TelaLogin : Form
    {
        //Declaração de variáveis e Objetos
        Label[] label = new Label[2];
        TextBox[] textBox = new TextBox[2];
        Button[] button = new Button[2];
        LinkLabel[] link = new LinkLabel[3];
        Session sessao = new Session();
        Bitmap loginImage;

        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public TelaLogin()
        {
            InitializeTelaLogin();   
        }

        public void InitializeTelaLogin()
        {
            //LABEL
            label[0] = new Label();
            label[0].Name = "lblUsuario";
            label[0].Text = "Usuário";
            label[0].Font = new Font(label[0].Name, 10);
            label[0].SetBounds(5, 70, 70, 20);

            label[1] = new Label();
            label[1].Name = "lblSenha";
            label[1].Text = "Senha";
            label[1].Font = new Font(label[1].Name, 10);
            label[1].SetBounds(5, 120, 70, 20);

            //TEXBOX
            textBox[0] = new TextBox();
            textBox[0].Name = "txtUsuario";
            textBox[0].MaxLength = 20;
            textBox[0].Font = new Font(textBox[0].Name, 10);
            textBox[0].SetBounds(95, 65, 120, 40);

            textBox[1] = new TextBox();
            textBox[1].Name = "txtSenha";
            textBox[1].MaxLength = 50;
            textBox[1].PasswordChar = '*';
            textBox[1].Font = new Font(textBox[1].Name, 10);
            textBox[1].SetBounds(95, 115, 120, 40);

            //BUTTON
            button[0] = new Button();
            button[0].Name = "btnEntrar";
            button[0].Text = "Entrar";
            button[0].SetBounds(55, 180, 80, 40);
            button[0].Click += new EventHandler(btnEntrar_Click);

            button[1] = new Button();
            button[1].Name = "btnCancelar";
            button[1].Text = "Cancelar";
            button[1].SetBounds(150, 180, 80, 40);
            button[1].Click += new EventHandler(btnCancelar_Click);

            //LINKLABEL
            link[0] = new LinkLabel();
            link[0].Name = "linkforgotPwd";
            link[0].Text = "Esqueci minha senha";
            link[0].SetBounds(5, 240, 120, 20);
            link[0].Click += new EventHandler(linkSenha_Click);

            link[1] = new LinkLabel();
            link[1].Name = "linkforgotUser";
            link[1].Text = "Esqueci meu usuário";
            link[1].SetBounds(135, 240, 120, 20);
            link[1].Click += new EventHandler(linkUsuario_Click);

            link[2] = new LinkLabel();
            link[2].Name = "linkCadastro";
            link[2].Text = "Cadastre-se";
            link[2].SetBounds(265, 240, 120, 20);
            link[2].Click += new EventHandler(linkCadastro_Click);

            //PICTUREBOX
            PictureBox pictureBox = new PictureBox();
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            loginImage = new Bitmap(@"Imagens\cadeado.bmp");
            pictureBox.ClientSize = new Size(100, 100);
            pictureBox.Image = (Image)loginImage;
            pictureBox.SetBounds(235, 65, 100, 100);

            //PANEL
            Panel pnlLogin = new Panel();
            pnlLogin.BorderStyle = BorderStyle.FixedSingle;
            pnlLogin.SetBounds(5, 5, 372, 260);
            pnlLogin.Controls.Add(label[0]);
            pnlLogin.Controls.Add(label[1]);
            pnlLogin.Controls.Add(textBox[0]);
            pnlLogin.Controls.Add(textBox[1]);
            pnlLogin.Controls.Add(button[0]);
            pnlLogin.Controls.Add(button[1]);
            pnlLogin.Controls.Add(link[0]);
            pnlLogin.Controls.Add(link[1]);
            pnlLogin.Controls.Add(link[2]);
            pnlLogin.Controls.Add(pictureBox);


            this.Text = "Login";
            this.Width = 400;
            this.Height = 310;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ControlBox = false;
            this.BackColor = Color.White;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Controls.Add(pnlLogin);
        }

        public void btnEntrar_Click(Object sender, EventArgs e)
        {
            strSql = "SELECT usuario, senha FROM LOGIN_TB WHERE usuario = @Usuario AND senha collate Latin1_General_CS_AS = @Senha;";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = textBox[0].Text;
            cmd.Parameters.Add("@Senha", SqlDbType.VarChar).Value = textBox[1].Text;

            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Columns.Add("Usuario", typeof(string));
                dt.Columns.Add("Senha", typeof(string));
                dt.Load(dr);

                String strUsuario = dt.Rows[0]["Usuario"].ToString();
                sessao.setUserSession(strUsuario);
                //Caso o login tenha sido realizado com sucesso o código abaixo cria uma nova thread e inicia o formulário principal
                Thread mainFormProcess = new Thread(TelaPrincipal_Load);
                mainFormProcess.Start();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Usuário ou senha invalidos", "Falha na autenticação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        public void btnCancelar_Click(Object sender, EventArgs e)
        {
            this.Close();
        }

        public void linkSenha_Click(Object sender, EventArgs e)
        {
            RecoverPassword recuperarSenha = new RecoverPassword();
            recuperarSenha.InitializeRecoverPassword();
            recuperarSenha.Show();
        }

        public void linkUsuario_Click(Object sender, EventArgs e)
        {
            RecoverUser lembrarUsuario = new RecoverUser();
            lembrarUsuario.InitializeRecoverUser();
            lembrarUsuario.Show();
        }

        public void linkCadastro_Click(Object sender, EventArgs e)
        {
            TelaCadastro cadastro = new TelaCadastro();
            cadastro.InitializeTelaCadastro();
            cadastro.Show();
        }

        public void TelaPrincipal_Load()
        {
            Application.Run(new FormPrincipal(sessao.getUserSession()));
        }
    }
}
