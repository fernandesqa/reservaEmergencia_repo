﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    class ConsultaBanco
    {
        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public String GetYearId(String strAno)
        {
            String idAno = "";
            strSql = "SELECT id_ano FROM ANO_TB WHERE ano = @Ano";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Ano", SqlDbType.VarChar).Value = strAno;

            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                idAno = Convert.ToString(dr["id_ano"]);
                dr.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }

            return idAno;
        }

        public String GetMonthId(String strMes)
        {
            String idMes = "";
            strSql = "SELECT id_mes FROM MESES_TB WHERE mes = @Mes";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Mes", SqlDbType.VarChar).Value = strMes;

            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                idMes = Convert.ToString(dr["id_mes"]);
                dr.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }

            return idMes;
        }

        public String GetIdAplicacao(String strAplicacao)
        {
            String idAplicacao = "";
            strSql = "SELECT id_aplicacao FROM TIPO_APLICACOES_TB WHERE aplicacao_nome = @Aplicacao";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Aplicacao", SqlDbType.VarChar).Value = strAplicacao;

            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                idAplicacao = Convert.ToString(dr["id_aplicacao"]);
                dr.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }

            return idAplicacao;
        }

        public void InsertYear(String strAno)
        {
            strSql = "INSERT INTO ANO_TB (ano) VALUES (@Ano)";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Ano", SqlDbType.VarChar).Value = strAno;

            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        public bool checkDataTable(String strQuery)
        {
            strSql = strQuery;
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);
            bool bResult = false;
            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                bResult = dr.HasRows;
            } catch (Exception e)
            {
                MessageBox.Show("Falha na Conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } finally
            {
                sqlCon.Close();
            }
            return bResult;
        }
    }
}
