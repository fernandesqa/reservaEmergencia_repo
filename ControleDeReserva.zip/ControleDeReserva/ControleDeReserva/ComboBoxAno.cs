﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class ComboBoxAno : ComboBox
    {
        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public void InitializeComboBoxAno()
        {
            strSql = "SELECT ANO FROM ANO_TB";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Columns.Add("ano", typeof(string));
                dt.Load(dr);

                this.DisplayMember = "ano";
                this.DataSource = dt;

            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }

        }
    }
}
