﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class ComboBoxTipo : ComboBox
    {
        public void InitializeComboBoxTipo()
        {
            this.Items.AddRange(new String[] {"Selecione","Despesas", "Aplicações", "Retiradas"});
            this.SelectedItem = "Selecione";
        }
    }
}
