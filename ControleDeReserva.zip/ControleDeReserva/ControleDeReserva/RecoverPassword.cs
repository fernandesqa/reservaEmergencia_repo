﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class RecoverPassword : Form
    {
        //Declaração de variáveis e objetos
        Label[] label = new Label[7];
        TextBox[] textBox = new TextBox[4];
        Button[] button = new Button[2];

        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public void InitializeRecoverPassword()
        {
            //LABEL
            label[0] = new Label();
            label[0].Name = "lblRecuperarUsuario";
            label[0].Text = "Recuperar senha";
            label[0].Font = new Font(label[0].Name, 18, FontStyle.Bold);
            label[0].SetBounds(5, 5, 300, 40);

            label[1] = new Label();
            label[1].Name = "lblNome";
            label[1].Text = "Nome";
            label[1].SetBounds(5, 100, 80, 20);

            label[2] = new Label();
            label[2].Name = "lblSobrenome";
            label[2].Text = "Sobrenome";
            label[2].SetBounds(5, 160, 80, 20);

            label[3] = new Label();
            label[3].Name = "lblPergunta";
            label[3].Text = "Pergunta";
            label[3].SetBounds(5, 220, 80, 20);

            label[4] = new Label();
            label[4].Name = "lblResposta";
            label[4].Text = "Resposta";
            label[4].SetBounds(5, 280, 80, 20);

            label[5] = new Label();
            label[5].Name = "lblInfoPergunta";
            label[5].ForeColor = Color.Blue;
            label[5].Font = new Font(label[5].Name, 8);
            label[5].SetBounds(100, 240, 200, 12);

            label[6] = new Label();
            label[6].Name = "lblInfoResposta";
            label[6].ForeColor = Color.Blue;
            label[6].Font = new Font(label[6].Name, 8);
            label[6].SetBounds(100, 300, 200, 12);

            //TEXTBOX
            textBox[0] = new TextBox();
            textBox[0].Name = "txtNome";
            textBox[0].SetBounds(100, 95, 160, 40);

            textBox[1] = new TextBox();
            textBox[1].Name = "txtSobrenome";
            textBox[1].SetBounds(100, 155, 160, 40);

            textBox[2] = new TextBox();
            textBox[2].Name = "txtPergunta";
            textBox[2].Enter += txtPergunta_Enter;
            textBox[2].Leave += txtPergunta_Leave;
            textBox[2].SetBounds(100, 215, 160, 40);

            textBox[3] = new TextBox();
            textBox[3].Name = "txtResposta";
            textBox[3].Enter += txtResposta_Enter;
            textBox[3].Leave += txtResposta_Leave;
            textBox[3].SetBounds(100, 275, 160, 40);

            //BUTTON
            button[0] = new Button();
            button[0].Name = "btnRecuperar";
            button[0].Text = "Recuperar";
            button[0].SetBounds(80, 320, 80, 40);
            button[0].Click += new EventHandler(btnRecuperar_Click);

            button[1] = new Button();
            button[1].Name = "btnCancelar";
            button[1].Text = "Cancelar";
            button[1].SetBounds(180, 320, 80, 40);
            button[1].Click += new EventHandler(btnCancelar_Click);

            //PANEL
            Panel pnlForgottenPassword = new Panel();
            pnlForgottenPassword.BorderStyle = BorderStyle.FixedSingle;
            pnlForgottenPassword.SetBounds(5, 5, 420, 390);
            pnlForgottenPassword.Controls.Add(label[0]);
            pnlForgottenPassword.Controls.Add(label[1]);
            pnlForgottenPassword.Controls.Add(label[2]);
            pnlForgottenPassword.Controls.Add(label[3]);
            pnlForgottenPassword.Controls.Add(label[4]);
            pnlForgottenPassword.Controls.Add(label[5]);
            pnlForgottenPassword.Controls.Add(label[6]);
            pnlForgottenPassword.Controls.Add(textBox[0]);
            pnlForgottenPassword.Controls.Add(textBox[1]);
            pnlForgottenPassword.Controls.Add(textBox[2]);
            pnlForgottenPassword.Controls.Add(textBox[3]);
            pnlForgottenPassword.Controls.Add(button[0]);
            pnlForgottenPassword.Controls.Add(button[1]);

            this.Text = "Recuperação de senha";
            this.Width = 450;
            this.Height = 450;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ControlBox = false;
            this.BackColor = Color.White;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Controls.Add(pnlForgottenPassword);
        }

        public void txtPergunta_Enter(Object sender, EventArgs e)
        {
            label[5].Text = "Informe a pergunta que foi cadastrada";
        }

        public void txtPergunta_Leave(Object sender, EventArgs e)
        {
            label[5].Text = "";
        }

        public void txtResposta_Enter(Object sender, EventArgs e)
        {
            label[6].Text = "Informe a resposta que foi cadastrada";
        }

        public void txtResposta_Leave(Object sender, EventArgs e)
        {
            label[6].Text = "";
        }

        public void btnRecuperar_Click(Object sender, EventArgs e)
        {
            strSql = "SELECT usuario FROM PESSOA_PERFIL_TB WHERE NOME = @Nome AND SOBRENOME = @Sobrenome AND PERGUNTA_SECRETA = @Pergunta AND RESPOSTA_SECRETA = @Resposta";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Nome", SqlDbType.VarChar).Value = textBox[0].Text;
            cmd.Parameters.Add("@Sobrenome", SqlDbType.VarChar).Value = textBox[1].Text;
            cmd.Parameters.Add("@Pergunta", SqlDbType.VarChar).Value = textBox[2].Text;
            cmd.Parameters.Add("@Resposta", SqlDbType.VarChar).Value = textBox[3].Text;

            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Columns.Add("usuario", typeof(string));
                dt.Load(dr);

                String strUser = dt.Rows[0]["usuario"].ToString();
                String strSenha = getPassword(strUser);
                MessageBox.Show("A sua senha é: " + strSenha, "Senha recuperada", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Usuário não encontrado na base de dados, verifique os dados informados!", "Usuário não encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        public void btnCancelar_Click(Object sender, EventArgs e)
        {
            this.Close();
        }

        private String getPassword(String strUsuario)
        {
            String strPassword = "";
            strSql = "SELECT senha FROM LOGIN_TB WHERE usuario ='"+strUsuario+"'";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Columns.Add("senha", typeof(string));
                dt.Load(dr);

                strPassword = dt.Rows[0]["senha"].ToString();
                return strPassword;
            } catch (Exception e)
            {
                return strPassword;
                MessageBox.Show("Erro ao acessar a tabela de Login", "Falha na conexão com o banco", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
