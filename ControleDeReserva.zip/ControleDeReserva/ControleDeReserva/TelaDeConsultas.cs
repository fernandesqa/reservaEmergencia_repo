﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class TelaDeConsultas : Form
    {
        //Declaração de objetos e variáveis
        Label[] label = new Label[4];
        ComboBoxMes comboBoxMes;
        ComboBoxAno comboBoxAno;
        ComboBoxTipo comboBoxTipo;
        ConsultaBanco banco = new ConsultaBanco();
        Button[] button = new Button[2];
        String strUserSession;
        DataGridView dtGridView = new DataGridView();
        SqlDataAdapter sAdapter;
        DataSet sDs;
        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public void InitializeConsultas(String strUserSession)
        {
            //Carrega a variável com o login do usuário logado
            this.strUserSession = strUserSession;

            //LABELS
            label[0] = new Label();
            label[0].Name = "lblConsulta";
            label[0].Text = "Consulta";
            label[0].Font = new Font(label[0].Name, 18, FontStyle.Bold);
            label[0].SetBounds(5, 5, 350, 50);

            label[1] = new Label();
            label[1].Name = "lblMes";
            label[1].Text = "Mês";
            label[1].SetBounds(5, 60, 30, 20);

            label[2] = new Label();
            label[2].Name = "lblAno";
            label[2].Text = "Ano";
            label[2].SetBounds(220, 60, 30, 20);

            label[3] = new Label();
            label[3].Name = "lblTipo";
            label[3].Text = "Tipo";
            label[3].SetBounds(435, 60, 30, 20);

            //COMBOBOX
            comboBoxMes = new ComboBoxMes();
            comboBoxMes.InitializeComboBoxMes();
            comboBoxMes.SetBounds(50, 55, 150, 80);

            comboBoxAno = new ComboBoxAno();
            comboBoxAno.InitializeComboBoxAno();
            comboBoxAno.SetBounds(265, 55, 150, 80);

            comboBoxTipo = new ComboBoxTipo();
            comboBoxTipo.InitializeComboBoxTipo();
            comboBoxTipo.SetBounds(480, 55, 150, 80);

            //Button
            Button btnBuscar = new Button();
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Text = "Buscar";
            btnBuscar.SetBounds(640, 53, 100, 25);
            btnBuscar.Click += new EventHandler(btnBuscar_Click);

            dtGridView.SetBounds(5, 100, 735, 300);

            //Panel
            Panel pnlConsulta = new Panel();
            pnlConsulta.BorderStyle = BorderStyle.FixedSingle;
            pnlConsulta.SetBounds(5, 5, 850, 440);
            pnlConsulta.Controls.Add(label[0]);
            pnlConsulta.Controls.Add(label[1]);
            pnlConsulta.Controls.Add(label[2]);
            pnlConsulta.Controls.Add(label[3]);
            pnlConsulta.Controls.Add(comboBoxMes);
            pnlConsulta.Controls.Add(comboBoxAno);
            pnlConsulta.Controls.Add(comboBoxTipo);
            pnlConsulta.Controls.Add(btnBuscar);
            pnlConsulta.Controls.Add(dtGridView);

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Icon = new Icon(@"Imagens\iconeConsulta.ico");
            this.Text = "Consultas";
            this.TopLevel = false;
            this.Width = 765;
            this.Height = 450;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.WindowState = FormWindowState.Maximized;
            this.Controls.Add(pnlConsulta);
        }

        public void btnBuscar_Click(Object sender, EventArgs e)
        {
            if (comboBoxTipo.Text.ToLower().Equals("despesas"))
            {
                if (!comboBoxAno.Text.ToLower().Equals("selecione") && !comboBoxMes.Text.ToLower().Equals("selecione"))
                {
                    strSql = "SELECT M.mes 'Mes', Y.ano, D.moradia 'Moradia', D.internetTvFixo 'Internet, TV e Fixo', D.luz 'Luz', D.cartaoDeCredito 'Cartão de crédito', D.educacao 'Educação', D.supermercado 'Supermercado', D.lazer 'Lazer', D.saude 'Saúde', D.contador 'Contador', D.transporte 'Transporte', D.inss 'INSS', D.outros 'Outros' FROM DESPESAS_TB D INNER JOIN MESES_TB M ON M.id_mes = D.id_mes AND D.usuario = '" + strUserSession + "' AND D.id_mes = '" + banco.GetMonthId(comboBoxMes.Text) + "' AND D.id_ano = '" + banco.GetYearId(comboBoxAno.Text) + "' INNER JOIN ANO_TB Y ON D.id_ano = Y.id_ano";
                }
                else if (!comboBoxAno.Text.ToLower().Equals("selecione") && comboBoxMes.Text.ToLower().Equals("selecione"))
                {
                    strSql = "SELECT M.mes 'Mes', Y.ano, D.moradia 'Moradia', D.internetTvFixo 'Internet, TV e Fixo', D.luz 'Luz', D.cartaoDeCredito 'Cartão de crédito', D.educacao 'Educação', D.supermercado 'Supermercado', D.lazer 'Lazer', D.saude 'Saúde', D.contador 'Contador', D.transporte 'Transporte', D.inss 'INSS', D.outros 'Outros' FROM DESPESAS_TB D INNER JOIN MESES_TB M ON M.id_mes = D.id_mes AND D.usuario = '" + strUserSession + "' AND D.id_ano = '" + banco.GetYearId(comboBoxAno.Text) + "' INNER JOIN ANO_TB Y ON D.id_ano = Y.id_ano";
                }
                else if (comboBoxAno.Text.ToLower().Equals("selecione") && !comboBoxMes.Text.ToLower().Equals("selecione"))
                {
                    strSql = "SELECT M.mes 'Mes', Y.ano, D.moradia 'Moradia', D.internetTvFixo 'Internet, TV e Fixo', D.luz 'Luz', D.cartaoDeCredito 'Cartão de crédito', D.educacao 'Educação', D.supermercado 'Supermercado', D.lazer 'Lazer', D.saude 'Saúde', D.contador 'Contador', D.transporte 'Transporte', D.inss 'INSS', D.outros 'Outros' FROM DESPESAS_TB D INNER JOIN MESES_TB M ON M.id_mes = D.id_mes AND D.usuario = '" + strUserSession + "' AND D.id_mes = '" + banco.GetMonthId(comboBoxMes.Text) + "' INNER JOIN ANO_TB Y ON D.id_ano = Y.id_ano";
                }
                else if (comboBoxAno.Text.ToLower().Equals("selecione") && comboBoxMes.Text.ToLower().Equals("selecione"))
                {
                    strSql = "SELECT M.mes 'Mes', Y.ano, D.moradia 'Moradia', D.internetTvFixo 'Internet, TV e Fixo', luz 'Luz', D.cartaoDeCredito 'Cartão de crédito', D.educacao 'Educação', D.supermercado 'Supermercado', D.lazer 'Lazer', D.saude 'Saúde', D.contador 'Contador', D.transporte 'Transporte', inss 'INSS', outros 'Outros' FROM DESPESAS_TB D INNER JOIN MESES_TB M ON M.id_mes = D.id_mes AND D.usuario = '" + strUserSession + "' INNER JOIN ANO_TB Y ON D.id_ano = Y.id_ano";
                }

                sqlCon = new SqlConnection(strCon);
                SqlCommand cmd = new SqlCommand(strSql, sqlCon);

                try
                {
                    if (banco.checkDataTable(strSql))
                    {
                        sqlCon.Open();
                        cmd.CommandType = CommandType.Text;
                        sAdapter = new SqlDataAdapter(cmd);
                        sDs = new DataSet();
                        dtGridView.ReadOnly = true;
                        sAdapter.Fill(sDs, "Despesas");
                        dtGridView.DataSource = sDs.Tables["Despesas"];
                    }
                    else
                    {
                        if (!comboBoxMes.Text.ToLower().Equals("selecione") && !comboBoxAno.Text.ToLower().Equals("selecione"))
                        {
                            MessageBox.Show("Não há dados de " + comboBoxTipo.Text + " cadastrados em " + comboBoxMes.Text + " de " + comboBoxAno.Text, "Dados não encontrados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else
                        {
                            MessageBox.Show("Não há dados de " + comboBoxTipo.Text + " cadastrados no período informado!", "Dados não encontrados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sqlCon.Close();
                }
            }
            else if (comboBoxTipo.Text.ToLower().Equals("aplicações"))
            {
                if (!comboBoxAno.Text.ToLower().Equals("selecione") && !comboBoxMes.Text.ToLower().Equals("selecione"))
                {
                    strSql = "SELECT M.mes 'Mes', Y.ano, T.aplicacao_nome 'Aplicação', A.valor 'Valor' FROM TIPO_APLICACOES_TB T INNER JOIN APLICACOES_FINANCEIRAS_TB A ON T.id_aplicacao = A.id_aplicacao AND A.usuario = '" + strUserSession + "' AND A.id_mes = '" + banco.GetMonthId(comboBoxMes.Text) + "' AND A.id_ano = '" + banco.GetYearId(comboBoxAno.Text) + "' INNER JOIN MESES_TB M ON M.id_mes = A.id_mes INNER JOIN ANO_TB Y ON A.id_ano = Y.id_ano";
                }
                else if (!comboBoxAno.Text.ToLower().Equals("selecione") && comboBoxMes.Text.ToLower().Equals("selecione"))
                {
                    strSql = "SELECT M.mes 'Mes', Y.ano, T.aplicacao_nome 'Aplicação', A.valor 'Valor' FROM TIPO_APLICACOES_TB T INNER JOIN APLICACOES_FINANCEIRAS_TB A ON T.id_aplicacao = A.id_aplicacao AND A.usuario = '" + strUserSession + "' AND A.id_ano = '" + banco.GetYearId(comboBoxAno.Text) + "' INNER JOIN MESES_TB M ON M.id_mes = A.id_mes INNER JOIN ANO_TB Y ON A.id_ano = Y.id_ano";
                }
                else if (comboBoxAno.Text.ToLower().Equals("selecione") && !comboBoxMes.Text.ToLower().Equals("selecione"))
                {
                    strSql = "SELECT M.mes 'Mes', Y.ano, T.aplicacao_nome 'Aplicação', A.valor 'Valor' FROM TIPO_APLICACOES_TB T INNER JOIN APLICACOES_FINANCEIRAS_TB A ON T.id_aplicacao = A.id_aplicacao AND A.usuario = '" + strUserSession + "' AND A.id_mes = '" + banco.GetMonthId(comboBoxMes.Text) + "' INNER JOIN MESES_TB M ON M.id_mes = A.id_mes INNER JOIN ANO_TB Y ON A.id_ano = Y.id_ano";
                }
                else if (comboBoxAno.Text.ToLower().Equals("selecione") && comboBoxMes.Text.ToLower().Equals("selecione"))
                {
                    strSql = "SELECT M.mes 'Mes', Y.ano 'Ano', T.aplicacao_nome 'Aplicação', A.valor 'Valor' FROM TIPO_APLICACOES_TB T INNER JOIN APLICACOES_FINANCEIRAS_TB A ON T.id_aplicacao = A.id_aplicacao AND A.usuario = '"+strUserSession+"' INNER JOIN MESES_TB M ON A.id_mes = M.id_mes INNER JOIN ANO_TB Y ON A.id_ano = Y.id_ano";
                }

                sqlCon = new SqlConnection(strCon);
                SqlCommand cmd = new SqlCommand(strSql, sqlCon);

                try
                {
                    if (banco.checkDataTable(strSql))
                    {
                        sqlCon.Open();
                        cmd.CommandType = CommandType.Text;
                        sAdapter = new SqlDataAdapter(cmd);
                        sDs = new DataSet();
                        dtGridView.ReadOnly = true;
                        sAdapter.Fill(sDs, "Aplicacoes");
                        dtGridView.DataSource = sDs.Tables["Aplicacoes"];
                    }
                    else
                    {
                        if (!comboBoxMes.Text.ToLower().Equals("selecione") && !comboBoxAno.Text.ToLower().Equals("selecione"))
                        {
                            MessageBox.Show("Não há dados de " + comboBoxTipo.Text + " cadastrados em " + comboBoxMes.Text + " de " + comboBoxAno.Text, "Dados não encontrados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else
                        {
                            MessageBox.Show("Não há dados de " + comboBoxTipo.Text + " cadastrados no período informado!", "Dados não encontrados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sqlCon.Close();
                }
            }
            else if (comboBoxTipo.Text.ToLower().Equals("retiradas"))
            {
                if (!comboBoxAno.Text.ToLower().Equals("selecione") && !comboBoxMes.Text.ToLower().Equals("selecione"))
                {
                    strSql = "SELECT dia 'Dia', mes 'Mes', ano 'Ano', horario 'Horário', valor 'Valor' FROM RETIRADAS_TB WHERE mes ='" + comboBoxMes.Text + "' AND ano ='" + comboBoxAno.Text + "' AND usuario ='" + strUserSession + "'";
                }
                else if (!comboBoxAno.Text.ToLower().Equals("selecione") && comboBoxMes.Text.ToLower().Equals("selecione"))
                {
                    strSql = "SELECT dia 'Dia', mes 'Mes', ano 'Ano', horario 'Horário', valor 'Valor' FROM RETIRADAS_TB WHERE ano ='" + comboBoxAno.Text + "' AND usuario ='" + strUserSession + "'";
                }
                else if (comboBoxAno.Text.ToLower().Equals("selecione") && !comboBoxMes.Text.ToLower().Equals("selecione"))
                {
                    strSql = "SELECT dia 'Dia', mes 'Mes', ano 'Ano', horario 'Horário', valor 'Valor' FROM RETIRADAS_TB WHERE mes ='" + comboBoxMes.Text + "' AND usuario ='" + strUserSession + "'";
                }
                else if (comboBoxAno.Text.ToLower().Equals("selecione") && comboBoxMes.Text.ToLower().Equals("selecione"))
                {
                    strSql = "SELECT dia 'Dia', mes 'Mes', ano 'Ano', horario 'Horário', valor 'Valor' FROM RETIRADAS_TB WHERE usuario ='" + strUserSession + "'";
                }

                sqlCon = new SqlConnection(strCon);
                SqlCommand cmd = new SqlCommand(strSql, sqlCon);

                try
                {
                    if (banco.checkDataTable(strSql))
                    {
                        sqlCon.Open();
                        cmd.CommandType = CommandType.Text;
                        sAdapter = new SqlDataAdapter(cmd);
                        sDs = new DataSet();
                        dtGridView.ReadOnly = true;
                        sAdapter.Fill(sDs, "Retiradas");
                        dtGridView.DataSource = sDs.Tables["Retiradas"];
                    }
                    else
                    {
                        if (!comboBoxMes.Text.ToLower().Equals("selecione") && !comboBoxAno.Text.ToLower().Equals("selecione"))
                        {
                            MessageBox.Show("Não há dados de " + comboBoxTipo.Text + " cadastrados em " + comboBoxMes.Text + " de " + comboBoxAno.Text, "Dados não encontrados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else
                        {
                            MessageBox.Show("Não há dados de " + comboBoxTipo.Text + " cadastrados no período informado!", "Dados não encontrados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sqlCon.Close();
                }
            }
            else
            {
                MessageBox.Show("Selecione um tipo de consulta!", "Dado não selecionado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
