﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class TelaDeAplicacoes : Form
    {
        //Declaração de variáveis e objetos
        Label[] label = new Label[4];
        ComboBoxMes comboBoxMes = new ComboBoxMes();
        ComboBoxTipoAplicacao comboBoxAplicacao = new ComboBoxTipoAplicacao();
        TextBoxMoeda textBox = new TextBoxMoeda();
        Button[] button = new Button[2];
        String strUserSession;
        Value format = new Value();
        Double dbTotal;
        ConsultaBanco banco = new ConsultaBanco();
        Datas data = new Datas();

        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public void InitializeAplicacoes(String strUserSession)
        {
            //Carrega a variável com o login do usuário logado
            this.strUserSession = strUserSession;

            //LABELS
            label[0] = new Label();
            label[0].Name = "lblCadastroAplicacoes";
            label[0].Text = "Cadastro de Aplicações";
            label[0].Font = new Font(label[0].Name, 18, FontStyle.Bold);
            label[0].SetBounds(5, 5, 350, 50);

            label[1] = new Label();
            label[1].Name = "lblMes";
            label[1].Text = "Mês";
            label[1].Font = new Font(label[1].Name, 12);
            label[1].SetBounds(5, 110, 50, 20);

            label[2] = new Label();
            label[2].Name = "lblTipoAplicacao";
            label[2].Text = "Tipo de Aplicação";
            label[2].Font = new Font(label[2].Name, 12);
            label[2].SetBounds(5, 150, 145, 20);

            label[3] = new Label();
            label[3].Name = "lblValor";
            label[3].Text = "Valor";
            label[3].Font = new Font(label[3].Name, 12);
            label[3].SetBounds(5, 190, 70, 20);


            //ComboBox
            comboBoxMes.InitializeComboBoxMes();
            comboBoxMes.SetBounds(150, 105, 150, 80);

            comboBoxAplicacao.InitializeComboBoxTipoAplicacao();
            comboBoxAplicacao.SetBounds(150, 145, 150, 80);

            //TextBox
            textBox.InitializeTextBox(textBox);
            textBox.SetBounds(150, 185, 120, 80);

            //BUTTON
            button[0] = new Button();
            button[0].Name = "btnSalvar";
            button[0].Text = "Salvar";
            button[0].Font = new Font(button[0].Name, 10);
            button[0].SetBounds(400, 300, 120, 80);
            button[0].Click += new EventHandler(btnSalvar_Click);

            button[1] = new Button();
            button[1].Name = "btnAlterar";
            button[1].Text = "Alterar";
            button[1].Font = new Font(button[1].Name, 10);
            button[1].SetBounds(540, 300, 120, 80);
            button[1].Click += new EventHandler(btnAlterar_Click);



            Panel pnlAplicacoes = new Panel();
            pnlAplicacoes.BorderStyle = BorderStyle.FixedSingle;
            pnlAplicacoes.SetBounds(5, 5, 850, 440);
            pnlAplicacoes.Controls.Add(label[0]);
            pnlAplicacoes.Controls.Add(label[1]);
            pnlAplicacoes.Controls.Add(label[2]);
            pnlAplicacoes.Controls.Add(label[3]);
            pnlAplicacoes.Controls.Add(comboBoxMes);
            pnlAplicacoes.Controls.Add(comboBoxAplicacao);
            pnlAplicacoes.Controls.Add(textBox);
            pnlAplicacoes.Controls.Add(button[0]);
            pnlAplicacoes.Controls.Add(button[1]);

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Icon = new Icon(@"Imagens\iconeAplicacoes.ico");
            this.Text = "Aplicações Financeiras";
            this.TopLevel = false;
            this.Width = 765;
            this.Height = 450;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.WindowState = FormWindowState.Maximized;
            this.Controls.Add(pnlAplicacoes);
        }

        public void btnSalvar_Click(Object sender, EventArgs e)
        {
            
            if (!comboBoxMes.Text.ToLower().Equals("selecione") && !comboBoxAplicacao.Text.ToLower().Equals("selecione"))
            {
                strSql = "INSERT INTO APLICACOES_FINANCEIRAS_TB VALUES (@Usuario, @idMes, @idAno, @idAplicacao, @Valor)";
                sqlCon = new SqlConnection(strCon);
                SqlCommand cmd = new SqlCommand(strSql, sqlCon);

                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;
                cmd.Parameters.Add("@idMes", SqlDbType.Int).Value = Convert.ToInt32(banco.GetMonthId(comboBoxMes.Text));
                cmd.Parameters.Add("@idAno", SqlDbType.Int).Value = Convert.ToInt32(banco.GetYearId(data.GetCurrentYear()));
                cmd.Parameters.Add("@idAplicacao", SqlDbType.Int).Value = Convert.ToInt32(banco.GetIdAplicacao(comboBoxAplicacao.Text));
                cmd.Parameters.Add("@Valor", SqlDbType.VarChar).Value = format.returnValue(textBox.Text.Replace(",", ".").Substring(3));

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Aplicação salva com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    totalAplicado();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Essa aplicação já foi realizada no mês informado!", "Aplicação já cadastrada", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                finally
                {
                    sqlCon.Close();
                }
            }
            else
            {
                MessageBox.Show("Selecione o mês e a aplicação");
            }
        }

        public void btnAlterar_Click(Object sender, EventArgs e)
        {
            TelaAlterarAplicacao alterarAplicacao = new TelaAlterarAplicacao();
            alterarAplicacao.InitializeTelaAlterarAplicacao(strUserSession);
            alterarAplicacao.Show();
        }

        private void totalAplicado()
        {
            strSql = "SELECT valor FROM APLICACOES_FINANCEIRAS_TB WHERE usuario ='"+strUserSession+"' AND id_aplicacao ="+banco.GetIdAplicacao(comboBoxAplicacao.Text)+"";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            try
            {
                if (banco.checkDataTable(strSql))
                {
                    sqlCon.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        dbTotal += Convert.ToDouble(dr["valor"]);
                    }
                    int iLength = dbTotal.ToString().Length - 3;
                    if (dbTotal.ToString().Substring(iLength, 1).Equals(","))
                    {
                        insertTotal(Convert.ToString(dbTotal).Replace(',', '.'));
                    }
                    else
                    {
                        insertTotal(Convert.ToString(dbTotal));
                    }
                
                    dr.Close();
                    dbTotal = 0.00;
                }
                else
                {
                    insertTotal(format.returnValue(textBox.Text.Replace(",", ".").Substring(3)));
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void insertTotal(String dbValor)
        {
            strSql = "SELECT * FROM TOTAL_APLICADO_TB WHERE usuario ='"+strUserSession+"' AND id_aplicacao ="+Convert.ToInt32(banco.GetIdAplicacao(comboBoxAplicacao.Text))+"";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            try
            {
                if (banco.checkDataTable(strSql))
                {
                    updateTotal(dbValor);
                }
                else
                {
                    strSql = "INSERT INTO TOTAL_APLICADO_TB (usuario, id_aplicacao, total) VALUES ('" + strUserSession + "'," + Convert.ToInt32(banco.GetIdAplicacao(comboBoxAplicacao.Text)) + ", '" + dbValor + "')";
                    SqlCommand insert = new SqlCommand(strSql, sqlCon);

                    sqlCon.Open();
                    insert.ExecuteNonQuery();
                }
                
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void updateTotal(String dbValor)
        {
            strSql = "UPDATE TOTAL_APLICADO_TB SET total = @Total WHERE usuario = @Usuario AND id_aplicacao = @idAplicacao";
            sqlCon = new SqlConnection(strCon);
            SqlCommand update = new SqlCommand(strSql, sqlCon);

            update.Parameters.Add("@Total", SqlDbType.VarChar).Value = dbValor;
            update.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;
            update.Parameters.Add("@idAplicacao", SqlDbType.Int).Value = Convert.ToInt32(banco.GetIdAplicacao(comboBoxAplicacao.Text));

            try
            {
                sqlCon.Open();
                update.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }
    }
}
