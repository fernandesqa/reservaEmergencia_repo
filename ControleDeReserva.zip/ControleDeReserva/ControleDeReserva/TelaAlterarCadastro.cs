﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class TelaAlterarCadastro : Form
    {
        //Declaração de variáveis e objetos
        private Label[] label = new Label[6];
        private TextBox[] textBox = new TextBox[5];
        private Button[] button = new Button[2];
        String strUserSession;

        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public void InitializeAlterarCadastro(String strUserSession)
        {
            //Carrega a variável com o login do usuário logado
            this.strUserSession = strUserSession;

            //LABELS
            label[0] = new Label();
            label[0].Name = "lblAlterarCadastro";
            label[0].Text = "Alterar Cadastro";
            label[0].Font = new Font(label[0].Name, 18, FontStyle.Bold);
            label[0].SetBounds(5, 5, 250, 50);

            label[1] = new Label();
            label[1].Name = "lblNome";
            label[1].Text = "Nome";
            label[1].Font = new Font(label[1].Name, 12);
            label[1].SetBounds(5, 100, 60, 20);

            label[2] = new Label();
            label[2].Name = "lblUsuario";
            label[2].Text = "Usuário";
            label[2].Font = new Font(label[2].Name, 12);
            label[2].SetBounds(5, 160, 80, 20);

            label[3] = new Label();
            label[3].Name = "lblTempoReserva";
            label[3].Text = "Tempo de Reserva";
            label[3].Font = new Font(label[3].Name, 12);
            label[3].SetBounds(5, 220, 150, 20);

            label[4] = new Label();
            label[4].Name = "lblPergunta";
            label[4].Text = "Pergunta";
            label[4].Font = new Font(label[4].Name, 12);
            label[4].SetBounds(5, 280, 150, 20);

            label[5] = new Label();
            label[5].Name = "lblResposta";
            label[5].Text = "Resposta";
            label[5].Font = new Font(label[5].Name, 12);
            label[5].SetBounds(5, 340, 150, 20);

            //Carrega os dados nos campos

            //TEXTBOXES
            textBox[0] = new TextBox();
            textBox[0].Name = "txtNome";
            textBox[0].Font = new Font(textBox[0].Name, 14);
            textBox[0].SetBounds(120, 95, 350, 180);

            textBox[1] = new TextBox();
            textBox[1].Name = "txtUsuario";
            textBox[1].Font = new Font(textBox[1].Name, 14);
            textBox[1].SetBounds(120, 155, 200, 180);

            textBox[2] = new TextBox();
            textBox[2].Name = "txtTempoDeReserva";
            textBox[2].Font = new Font(textBox[2].Name, 14);
            textBox[2].SetBounds(160, 220, 40, 180);

            textBox[3] = new TextBox();
            textBox[3].Name = "txtPergunta";
            textBox[3].Font = new Font(textBox[3].Name, 14);
            textBox[3].SetBounds(160, 275, 350, 180);

            textBox[4] = new TextBox();
            textBox[4].Name = "txtResposta";
            textBox[4].Font = new Font(textBox[4].Name, 14);
            textBox[4].SetBounds(160, 335, 350, 180);

            //BUTTONS
            button[0] = new Button();
            button[0].Name = "btnSalvar";
            button[0].Text = "Salvar";
            button[0].SetBounds(535, 410, 90, 40);
            button[0].Click += new EventHandler(btnSalvar_Click);

            button[1] = new Button();
            button[1].Name = "btnCancelar";
            button[1].Text = "Cancelar";
            button[1].SetBounds(635, 410, 90, 40);
            button[1].Click += new EventHandler(btnCancelar_Click);

            //PANEL
            Panel pnlAlterarCadastro = new Panel();
            pnlAlterarCadastro.BorderStyle = BorderStyle.FixedSingle;
            pnlAlterarCadastro.SetBounds(5, 5, 735, 460);
            pnlAlterarCadastro.Controls.Add(label[0]);
            pnlAlterarCadastro.Controls.Add(label[1]);
            pnlAlterarCadastro.Controls.Add(label[2]);
            pnlAlterarCadastro.Controls.Add(label[3]);
            pnlAlterarCadastro.Controls.Add(label[4]);
            pnlAlterarCadastro.Controls.Add(label[5]);
            pnlAlterarCadastro.Controls.Add(button[0]);
            pnlAlterarCadastro.Controls.Add(button[1]);
            pnlAlterarCadastro.Controls.Add(textBox[0]);
            pnlAlterarCadastro.Controls.Add(textBox[1]);
            pnlAlterarCadastro.Controls.Add(textBox[2]);
            pnlAlterarCadastro.Controls.Add(textBox[3]);
            pnlAlterarCadastro.Controls.Add(textBox[4]);

            this.Text = "Alteração de Cadastro";
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ControlBox = false;
            this.Width = 765;
            this.Height = 510;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Controls.Add(pnlAlterarCadastro);

            dadosUsuario_Load();
        }

        private void dadosUsuario_Load()
        {
            strSql = "SELECT nome, sobrenome, tempoReserva, pergunta, resposta FROM PESSOA_PERFIL_TB WHERE usuario = @Usuario";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;

            try
            {
                sqlCon.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                dr.Read();

                textBox[0].Text = dr["nome"].ToString();
                textBox[1].Text = dr["sobrenome"].ToString();
                textBox[2].Text = dr["tempoReserva"].ToString();
                textBox[3].Text = dr["pergunta"].ToString();
                textBox[4].Text = dr["resposta"].ToString();

                dr.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        public void btnSalvar_Click(Object sender, System.EventArgs e)
        {
            strSql = "UPDATE PESSOA_PERFIL_TB SET nome = @Nome, sobrenome = @Sobrenome, tempoReserva = @TempoReserva, pergunta = @pergunta, resposta = @Resposta WHERE usuario = @Usuario";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Nome", SqlDbType.VarChar).Value = textBox[0].Text;
            cmd.Parameters.Add("@Sobrenome", SqlDbType.VarChar).Value = textBox[1].Text;
            cmd.Parameters.Add("@TempoReserva", SqlDbType.VarChar).Value = textBox[2].Text;
            cmd.Parameters.Add("@Pergunta", SqlDbType.VarChar).Value = textBox[3].Text;
            cmd.Parameters.Add("@Resposta", SqlDbType.VarChar).Value = textBox[4].Text;
            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;

            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Alteração de cadastro realizada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        public void btnCancelar_Click(Object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
