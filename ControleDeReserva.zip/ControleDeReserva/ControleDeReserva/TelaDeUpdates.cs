﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class TelaDeUpdates : Form
    {
        //Declaração de variáveis e objetos
        private Label[] label = new Label[15];
        private TextBoxMoeda[] textBox = new TextBoxMoeda[12];
        private ComboBoxMes cbMes;
        private ComboBoxAno cbAno;
        private Button[] button = new Button[2];
        String strUserSession;
        ConsultaBanco banco = new ConsultaBanco();
        Value valor = new Value();

        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public void InitializeUpdates(String strUserSession)
        {
            //Carrega a variável com o login do usuário logado
            this.strUserSession = strUserSession;

            //LABELS
            label[0] = new Label();
            label[0].Name = "lblAlterarDespesas";
            label[0].Text = "Alterar dados de Despesas";
            label[0].Font = new Font(label[0].Name, 18, FontStyle.Bold);
            label[0].SetBounds(5, 5, 350, 50);

            label[1] = new Label();
            label[1].Name = "lblMes";
            label[1].Text = "Mês";
            label[1].SetBounds(5, 60, 30, 20);

            label[2] = new Label();
            label[2].Name = "lblAno";
            label[2].Text = "Ano";
            label[2].SetBounds(220, 60, 30, 20);

            label[3] = new Label();
            label[3].Name = "lblMoradia";
            label[3].Text = "Moradia";
            label[3].SetBounds(5, 100, 60, 20);

            label[4] = new Label();
            label[4].Name = "lblInternetTvFixo";
            label[4].Text = "Internet + Tv + Fixo";
            label[4].SetBounds(5, 140, 110, 20);

            label[5] = new Label();
            label[5].Name = "lblLuz";
            label[5].Text = "Luz";
            label[5].SetBounds(5, 180, 30, 20);

            label[6] = new Label();
            label[6].Name = "lblCartaoCredito";
            label[6].Text = "Cartão de Crédito";
            label[6].SetBounds(5, 220, 100, 20);

            label[7] = new Label();
            label[7].Name = "lblEducacao";
            label[7].Text = "Educação";
            label[7].SetBounds(5, 260, 60, 20);

            label[8] = new Label();
            label[8].Name = "lblSupermercado";
            label[8].Text = "Supermercado";
            label[8].SetBounds(5, 300, 100, 20);

            label[9] = new Label();
            label[9].Name = "lblLazer";
            label[9].Text = "Lazer";
            label[9].SetBounds(380, 100, 50, 20);

            label[10] = new Label();
            label[10].Name = "lblSaude";
            label[10].Text = "Saúde";
            label[10].SetBounds(380, 140, 50, 20);

            label[11] = new Label();
            label[11].Name = "lblContador";
            label[11].Text = "Contador";
            label[11].SetBounds(380, 180, 60, 20);

            label[12] = new Label();
            label[12].Name = "lblTransporte";
            label[12].Text = "Transporte";
            label[12].SetBounds(380, 220, 60, 20);

            label[13] = new Label();
            label[13].Name = "lblInss";
            label[13].Text = "INSS";
            label[13].SetBounds(380, 260, 40, 20);

            label[14] = new Label();
            label[14].Name = "lblOutros";
            label[14].Text = "Outros";
            label[14].SetBounds(380, 300, 60, 20);

            //COMBOBOX
            cbMes = new ComboBoxMes();
            cbMes.InitializeComboBoxMes();
            cbMes.SetBounds(50, 55, 150, 80);

            cbAno = new ComboBoxAno();
            cbAno.InitializeComboBoxAno();
            cbAno.SetBounds(265, 55, 150, 80);

            //TEXTBOX
            textBox[0] = new TextBoxMoeda();
            textBox[0].Name = "txtMoradia";
            textBox[0].InitializeTextBox(textBox[0]);
            textBox[0].SetBounds(115, 95, 120, 80);

            textBox[1] = new TextBoxMoeda();
            textBox[1].Name = "txtInternetTVFixo";
            textBox[1].InitializeTextBox(textBox[1]);
            textBox[1].SetBounds(115, 135, 120, 80);

            textBox[2] = new TextBoxMoeda();
            textBox[2].Name = "txtLuz";
            textBox[2].InitializeTextBox(textBox[2]);
            textBox[2].SetBounds(115, 170, 120, 80);

            textBox[3] = new TextBoxMoeda();
            textBox[3].Name = "txCartaoDeCredito";
            textBox[3].InitializeTextBox(textBox[3]);
            textBox[3].SetBounds(115, 215, 120, 80);

            textBox[4] = new TextBoxMoeda();
            textBox[4].Name = "txtEducacao";
            textBox[4].InitializeTextBox(textBox[4]);
            textBox[4].SetBounds(115, 255, 120, 80);

            textBox[5] = new TextBoxMoeda();
            textBox[5].Name = "txtSupermercado";
            textBox[5].InitializeTextBox(textBox[5]);
            textBox[5].SetBounds(115, 295, 120, 80);

            textBox[6] = new TextBoxMoeda();
            textBox[6].Name = "txtLazer";
            textBox[6].InitializeTextBox(textBox[6]);
            textBox[6].SetBounds(450, 95, 120, 80);

            textBox[7] = new TextBoxMoeda();
            textBox[7].Name = "txtSaude";
            textBox[7].InitializeTextBox(textBox[7]);
            textBox[7].SetBounds(450, 135, 120, 80);

            textBox[8] = new TextBoxMoeda();
            textBox[8].Name = "txtContador";
            textBox[8].InitializeTextBox(textBox[8]);
            textBox[8].SetBounds(450, 175, 120, 80);

            textBox[9] = new TextBoxMoeda();
            textBox[9].Name = "txtTransporte";
            textBox[9].InitializeTextBox(textBox[9]);
            textBox[9].SetBounds(450, 215, 120, 80);

            textBox[10] = new TextBoxMoeda();
            textBox[10].Name = "txtInss";
            textBox[10].InitializeTextBox(textBox[10]);
            textBox[10].SetBounds(450, 255, 120, 80);

            textBox[11] = new TextBoxMoeda();
            textBox[11].Name = "txtOutros";
            textBox[11].InitializeTextBox(textBox[11]);
            textBox[11].SetBounds(450, 295, 120, 80);

            //Button
            button[0] = new Button();
            button[0].Name = "btnSalvar";
            button[0].Text = "Salvar";
            button[0].SetBounds(470, 350, 100, 50);
            button[0].Click += new EventHandler(btnSalvar_Click);

            button[1] = new Button();
            button[1].Name = "btnBuscar";
            button[1].Text = "Buscar";
            button[1].SetBounds(430, 53, 100, 25);
            button[1].Click += new EventHandler(btnBuscar_Click);

            //PANEL
            Panel pnlDespesas = new Panel();
            pnlDespesas.BorderStyle = BorderStyle.FixedSingle;
            pnlDespesas.SetBounds(5, 5, 850, 440);
            pnlDespesas.Controls.Add(label[0]);
            pnlDespesas.Controls.Add(label[1]);
            pnlDespesas.Controls.Add(label[2]);
            pnlDespesas.Controls.Add(label[3]);
            pnlDespesas.Controls.Add(label[4]);
            pnlDespesas.Controls.Add(label[5]);
            pnlDespesas.Controls.Add(label[6]);
            pnlDespesas.Controls.Add(label[7]);
            pnlDespesas.Controls.Add(label[8]);
            pnlDespesas.Controls.Add(label[9]);
            pnlDespesas.Controls.Add(label[10]);
            pnlDespesas.Controls.Add(label[11]);
            pnlDespesas.Controls.Add(label[12]);
            pnlDespesas.Controls.Add(label[13]);
            pnlDespesas.Controls.Add(label[14]);
            pnlDespesas.Controls.Add(cbMes);
            pnlDespesas.Controls.Add(cbAno);
            pnlDespesas.Controls.Add(textBox[0]);
            pnlDespesas.Controls.Add(textBox[1]);
            pnlDespesas.Controls.Add(textBox[2]);
            pnlDespesas.Controls.Add(textBox[3]);
            pnlDespesas.Controls.Add(textBox[4]);
            pnlDespesas.Controls.Add(textBox[5]);
            pnlDespesas.Controls.Add(textBox[6]);
            pnlDespesas.Controls.Add(textBox[7]);
            pnlDespesas.Controls.Add(textBox[8]);
            pnlDespesas.Controls.Add(textBox[9]);
            pnlDespesas.Controls.Add(textBox[10]);
            pnlDespesas.Controls.Add(textBox[11]);
            pnlDespesas.Controls.Add(button[0]);
            pnlDespesas.Controls.Add(button[1]);

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Icon = new Icon(@"Imagens\iconeUpdate.ico");
            this.Text = "Alteração de despesas";
            this.TopLevel = false;
            this.Width = 765;
            this.Height = 450;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.WindowState = FormWindowState.Maximized;
            this.Controls.Add(pnlDespesas);
        }

        public void btnBuscar_Click(Object sender, EventArgs e)
        {
            strSql = "SELECT moradia, InternetTvFixo, luz, cartaoDeCredito, educacao, supermercado, lazer, saude, contador, transporte, inss, outros FROM DESPESAS_TB WHERE usuario = @Usuario AND id_mes = @idMes AND id_ano = @idAno";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;
            cmd.Parameters.Add("@idMes", SqlDbType.Int).Value = Convert.ToInt32(banco.GetMonthId(cbMes.Text));
            cmd.Parameters.Add("@idAno", SqlDbType.Int).Value = Convert.ToInt32(banco.GetYearId(cbAno.Text));

            if (cbMes.Text.ToLower().Equals("selecione") || cbAno.Text.ToLower().Equals("selecione"))
            {
                MessageBox.Show("Você deve selecionar o ano e o mês da despesa");
            }
            else
            {
                try
                {
                    sqlCon.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    textBox[0].Text = Convert.ToString(dr["moradia"]);
                    textBox[1].Text = Convert.ToString(dr["InternetTvFixo"]);
                    textBox[2].Text = Convert.ToString(dr["luz"]);
                    textBox[3].Text = Convert.ToString(dr["cartaoDeCredito"]);
                    textBox[4].Text = Convert.ToString(dr["educacao"]);
                    textBox[5].Text = Convert.ToString(dr["supermercado"]);
                    textBox[6].Text = Convert.ToString(dr["lazer"]);
                    textBox[7].Text = Convert.ToString(dr["saude"]);
                    textBox[8].Text = Convert.ToString(dr["contador"]);
                    textBox[9].Text = Convert.ToString(dr["transporte"]);
                    textBox[10].Text = Convert.ToString(dr["inss"]);
                    textBox[11].Text = Convert.ToString(dr["outros"]);
                    dr.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Não há despesas cadastradas no mês informado", "Dado não encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                finally
                {
                    sqlCon.Close();
                }
            }
        }

        public void btnSalvar_Click(Object sender, EventArgs e)
        {
            strSql = "UPDATE DESPESAS_TB SET moradia = @Moradia, InternetTvFixo = @InternetTvFixo, luz = @Luz, cartaoDeCredito = @CartaoDeCredito, educacao = @Educacao, supermercado = @Supermercado, lazer = @Lazer, saude = @Saude, contador = @Contador, transporte = @Transporte, inss = @Inss, outros = @Outros WHERE usuario = @Usuario AND id_mes = @idMes AND id_ano = @idAno";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);
            
            cmd.Parameters.Add("@Moradia", SqlDbType.VarChar).Value = valor.returnValue(textBox[0].Text.Replace(",", "."));
            cmd.Parameters.Add("@InternetTvFixo", SqlDbType.VarChar).Value = valor.returnValue(textBox[1].Text.Replace(",", "."));
            cmd.Parameters.Add("@Luz", SqlDbType.VarChar).Value = valor.returnValue(textBox[2].Text.Replace(",", "."));
            cmd.Parameters.Add("@CartaoDeCredito", SqlDbType.VarChar).Value = valor.returnValue(textBox[3].Text.Replace(",", "."));
            cmd.Parameters.Add("@Educacao", SqlDbType.VarChar).Value = valor.returnValue(textBox[4].Text.Replace(",", "."));
            cmd.Parameters.Add("@Supermercado", SqlDbType.VarChar).Value = valor.returnValue(textBox[5].Text.Replace(",", "."));
            cmd.Parameters.Add("@Lazer", SqlDbType.VarChar).Value = valor.returnValue(textBox[6].Text.Replace(",", "."));
            cmd.Parameters.Add("@Saude", SqlDbType.VarChar).Value = valor.returnValue(textBox[7].Text.Replace(",", "."));
            cmd.Parameters.Add("@Contador", SqlDbType.VarChar).Value = valor.returnValue(textBox[8].Text.Replace(",", "."));
            cmd.Parameters.Add("@Transporte", SqlDbType.VarChar).Value = valor.returnValue(textBox[9].Text.Replace(",", "."));
            cmd.Parameters.Add("@Inss", SqlDbType.VarChar).Value = valor.returnValue(textBox[10].Text.Replace(",", "."));
            cmd.Parameters.Add("@Outros", SqlDbType.VarChar).Value = valor.returnValue(textBox[11].Text.Replace(",", "."));
            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;
            cmd.Parameters.Add("@idMes", SqlDbType.Int).Value = Convert.ToInt32(banco.GetMonthId(cbMes.Text));
            cmd.Parameters.Add("@idAno", SqlDbType.Int).Value = Convert.ToInt32(banco.GetYearId(cbAno.Text));

            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Despesas atualizadas com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                updateTotalDespesas();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void updateTotalDespesas()
        {
            strSql = "UPDATE TOTAL_DESPESAS_TB SET total = @Total WHERE usuario = @Usuario AND id_mes = @idMes AND id_ano = @idAno";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);
            Double dbTotal = 0.00;
            String strValor = "";
            int iTotCarac = 0;

            for (int i = 0; i <= 11; i++)
            {
                if (textBox[i].Text.Substring(0, 1).ToLower().Equals("r"))
                {
                    strValor = textBox[i].Text.Replace(',', '.').Substring(3);
                    iTotCarac = strValor.Length;

                    if (strValor.Substring(iTotCarac - 1, 1).Equals("0") && strValor.Substring(iTotCarac - 2, 1).Equals("0"))
                    {
                        strValor = strValor.Substring(0, iTotCarac - 3);
                        dbTotal += Convert.ToDouble(strValor);
                    }
                    else
                    {
                        strValor = textBox[i].Text.Substring(3);
                        dbTotal += Convert.ToDouble(strValor);
                    }
                }
                else
                {
                    dbTotal += Convert.ToDouble(textBox[i].Text);
                }
                
            }

            iTotCarac = dbTotal.ToString().Length;

            Boolean bContainsComa = false;

            for (int j = 0; j < iTotCarac; j++)
            {
                if (dbTotal.ToString().Substring(j, 1).Equals(","))
                {
                    bContainsComa = true;
                }
            }

            if (bContainsComa)
            {
                strValor = dbTotal.ToString().Replace(',', '.');
            }

            cmd.Parameters.Add("@Total", SqlDbType.VarChar).Value = strValor;
            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;
            cmd.Parameters.Add("@idMes", SqlDbType.Int).Value = Convert.ToInt32(banco.GetMonthId(cbMes.Text));
            cmd.Parameters.Add("@idAno", SqlDbType.Int).Value = Convert.ToInt32(banco.GetYearId(cbAno.Text));

            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
                dbTotal = 0.00;
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }
    }
}
