﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public class CalculoReserva
    {
        String strMedia = "";
        String strTotal = "";
        String strTotalAplicado = "";
        String strReservaAtual = "";
        Double dMedia;

        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public String media(String strUserSession)
        {
            Double dTotal = 0;
            int iTotRows = 0;
            strSql = "SELECT total FROM TOTAL_DESPESAS_TB WHERE usuario = @Usuario";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;

            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);
                if (dt.Rows.Count > 0)
                {
                    iTotRows = dt.Rows.Count;
                    DataRow row;
                    for (int i = 0; i < iTotRows; i++)
                    {
                        row = dt.Rows[i];
                        dTotal += Convert.ToDouble(row["total"]);
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }

            int iTotValores;
            iTotValores = iTotRows;

            dMedia = dTotal /iTotValores;
            strMedia = "R$ " + formatValue(Math.Round(dMedia, 2).ToString());
            return strMedia;
        }

        public String total(String strUserSession)
        {
            Double dbTotal = 0.00;
            strSql = "SELECT total FROM TOTAL_APLICADO_TB WHERE usuario = @Usuario";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;

            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                DataRow row;
                dt.Load(dr);
                if (dt.Rows.Count>0)
                {
                    int iTotRows = dt.Rows.Count;

                    for (int i = 0; i < iTotRows; i++)
                    {
                        row = dt.Rows[i];
                        dbTotal += Convert.ToDouble(row["total"]);
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
            strTotalAplicado = dbTotal.ToString();
            strTotal = "R$ "+ formatValue(strTotalAplicado);
            return strTotal;
        }

        public String metaDaReserva(String strUserSession)
        {
            Double dTempoReservaInformada, dReservaTotal;
            strSql = "SELECT tempoReserva FROM PESSOA_PERFIL_TB WHERE usuario = @Usuario";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;

            dTempoReservaInformada = 0;

            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                dTempoReservaInformada = Convert.ToDouble(dr["tempoReserva"]);
                dr.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }

            dReservaTotal = Math.Round(dMedia, 2) * dTempoReservaInformada;

            String strMetaDeReserva = "R$ "+ formatValue(dReservaTotal.ToString());
          
            return strMetaDeReserva;
        }

        public String reservaAtual()
        {
            dMedia = Math.Round(dMedia, 2);
            Double dTotalAplicado = Convert.ToDouble(strTotalAplicado);
            
            if (dMedia > dTotalAplicado || dMedia.ToString().ToLower().Equals("nan"))
            {
                strReservaAtual = "menos de 1 mês";
            } else if (dMedia <= dTotalAplicado && dMedia * 2 > dTotalAplicado)
            {
                strReservaAtual = "1 mês";
            } else if (dMedia * 2 <= dTotalAplicado && dMedia * 3 > dTotalAplicado)
            {
                strReservaAtual = "2 meses";
            }
            else if (dMedia * 3 <= dTotalAplicado && dMedia * 4 > dTotalAplicado)
            {
                strReservaAtual = "3 meses";
            }
            else if (dMedia * 4 <= dTotalAplicado && dMedia * 5 > dTotalAplicado)
            {
                strReservaAtual = "4 meses";
            }
            else if (dMedia * 5 <= dTotalAplicado && dMedia * 6 > dTotalAplicado)
            {
                strReservaAtual = "5 meses";
            }
            else if (dMedia * 6 <= dTotalAplicado && dMedia * 7 > dTotalAplicado)
            {
                strReservaAtual = "6 meses";
            }
            else if (dMedia * 7 <= dTotalAplicado && dMedia * 8 > dTotalAplicado)
            {
                strReservaAtual = "7 meses";
            }
            else if (dMedia * 8 <= dTotalAplicado && dMedia * 9 > dTotalAplicado)
            {
                strReservaAtual = "8 meses";
            }
            else if (dMedia * 9 <= dTotalAplicado && dMedia * 10 > dTotalAplicado)
            {
                strReservaAtual = "9 meses";
            }
            else if (dMedia * 10 <= dTotalAplicado && dMedia * 11 > dTotalAplicado)
            {
                strReservaAtual = "10 meses";
            }
            else if (dMedia * 11 <= dTotalAplicado && dMedia * 12 > dTotalAplicado)
            {
                strReservaAtual = "11 meses";
            } else if (dMedia * 12 == dTotalAplicado)
            {
                strReservaAtual = "1 ano";
            }
            else
            {
                strReservaAtual = "mais de 1 ano";
            }
            return strReservaAtual;
        }

        private String formatValue(String strValor)
        {
            String strFormatedValue = "";
            String strAux;
            int iLength;
          
            if (strValor != "NAN" || strValor.Length >= 4)
            {
                iLength = strValor.Length - 2;
                if (strValor.Substring(iLength, 1).Equals(","))
                {
                    strValor = strValor + "0";
    
                }
                iLength = strValor.Length - 3;
                strAux = strValor.Substring(iLength, 1);

                if (strAux != ",")
                {
                    if (strValor.Length >= 4)
                    {
                        if (strValor.Length.Equals(7))
                        {
                            strAux = strValor.Substring(0, 1);
                            strAux += ".";
                            strAux += strValor.Substring(1, 3);
                            strAux += ".";
                            strAux += strValor.Substring(4, 3);
                            strAux += ",00";
                            strFormatedValue = strAux;
                        }
                        else if (strValor.Length.Equals(6))
                        {
                            strAux = strValor.Substring(0, 3);
                            strAux += ".";
                            strAux += strValor.Substring(4, 3);
                            strValor += ",00";
                            strFormatedValue = strAux;
                        }
                        else if (strValor.Length.Equals(5))
                        {
                            strAux = strValor.Substring(0, 2);
                            strAux += ".";
                            strAux += strValor.Substring(2, 3);
                            strAux += ",00";
                            strFormatedValue = strAux;
                        }
                        else if (strValor.Length.Equals(4))
                        {
                            strAux = strValor.Substring(0, 1);
                            strAux += ".";
                            strAux += strValor.Substring(1, 3);
                            strAux += ",00";
                            strFormatedValue = strAux;
                        }
                    }
                    else
                    {
                        strFormatedValue = strValor + ",00";
                    }
                }
                else
                {
                    if (strValor.Length >= 7)
                    {
                        if (strValor.Length.Equals(10))
                        {
                            strAux = strValor.Substring(0, 1);
                            strAux += ".";
                            strAux += strValor.Substring(1, 3);
                            strAux += ".";
                            strAux += strValor.Substring(4, 6);
                            strFormatedValue = strAux;
                        }
                        else if (strValor.Length.Equals(9))
                        {
                            strAux = strValor.Substring(0, 3);
                            strAux += ".";
                            strAux += strValor.Substring(3, 6);
                            strFormatedValue = strAux;
                        }
                        else if (strValor.Length.Equals(8))
                        {
                            strAux = strValor.Substring(0, 2);
                            strAux += ".";
                            strAux += strValor.Substring(2, 6);
                            strFormatedValue = strAux;
                        }
                        else if (strValor.Length.Equals(7))
                        {
                            strAux = strValor.Substring(0, 1);
                            strAux += ".";
                            strAux += strValor.Substring(1, 6);
                            strFormatedValue = strAux;
                        }
                    }
                }
            }
            else
            {
                strFormatedValue = "0,00";
            }
            return strFormatedValue;
        }
    }
}
