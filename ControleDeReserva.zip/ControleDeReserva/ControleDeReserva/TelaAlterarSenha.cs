﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class TelaAlterarSenha : Form
    {
        //Declaração de variáveis e objetos
        private Label[] label = new Label[3];
        private TextBox[] textBox = new TextBox[3];
        private Button[] button = new Button[2];
        String strUserSession;

        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public void InitializeTelaAlterarSenha(String strUserSession)
        {
            //Carrega a variável com o login do usuário logado
            this.strUserSession = strUserSession;

            //LABELS
            label[0] = new Label();
            label[0].Name = "lblSenhaAtual";
            label[0].Text = "Senha Atual";
            label[0].Font = new Font(label[0].Font.Name, 10);
            label[0].SetBounds(5, 35, 100, 20);

            label[1] = new Label();
            label[1].Name = "lblNovaSenha";
            label[1].Text = "Nova Senha";
            label[1].Font = new Font(label[1].Font.Name, 10);
            label[1].SetBounds(5, 85, 100, 20);

            label[2] = new Label();
            label[2].Name = "lblConfirmarSenha";
            label[2].Text = "Confirmar Senha";
            label[2].Font = new Font(label[2].Font.Name, 10);
            label[2].SetBounds(5, 135, 120, 20);

            //TEXTBOXES
            textBox[0] = new TextBox();
            textBox[0].Name = "txtSenhaAtual";
            textBox[0].PasswordChar = '*';
            textBox[0].Font = new Font(textBox[0].Name, 14, FontStyle.Bold);
            textBox[0].MaxLength = 20;
            textBox[0].SetBounds(130, 30, 130, 80);

            textBox[1] = new TextBox();
            textBox[1].Name = "txtNovaSenha";
            textBox[1].PasswordChar = '*';
            textBox[1].Font = new Font(textBox[1].Name, 14, FontStyle.Bold);
            textBox[1].MaxLength = 20;
            textBox[1].SetBounds(130, 80, 130, 80);

            textBox[2] = new TextBox();
            textBox[2].Name = "txtConfirmarSenha";
            textBox[2].PasswordChar = '*';
            textBox[2].Font = new Font(textBox[2].Name, 14, FontStyle.Bold);
            textBox[2].MaxLength = 20;
            textBox[2].SetBounds(130, 130, 130, 80);

            //BUTTONS
            button[0] = new Button();
            button[0].Name = "btnAlterar";
            button[0].Text = "Alterar";
            button[0].SetBounds(70, 185, 90, 40);
            button[0].Click += new EventHandler(btnAlterar_Click);

            button[1] = new Button();
            button[1].Name = "btnCancelar";
            button[1].Text = "Cancelar";
            button[1].SetBounds(170, 185, 90, 40);
            button[1].Click += new EventHandler(btnCancelar_Click);

            //Panel
            Panel pnlAlterarSenha = new Panel();
            pnlAlterarSenha.BorderStyle = BorderStyle.FixedSingle;
            pnlAlterarSenha.SetBounds(5, 5, 270, 250);
            pnlAlterarSenha.Controls.Add(label[0]);
            pnlAlterarSenha.Controls.Add(label[1]);
            pnlAlterarSenha.Controls.Add(label[2]);
            pnlAlterarSenha.Controls.Add(textBox[0]);
            pnlAlterarSenha.Controls.Add(textBox[1]);
            pnlAlterarSenha.Controls.Add(textBox[2]);
            pnlAlterarSenha.Controls.Add(button[0]);
            pnlAlterarSenha.Controls.Add(button[1]);

            this.Text = "Alterar Senha";
            this.MinimizeBox = false;
            this.MaximizeBox = false;
            this.ControlBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Controls.Add(pnlAlterarSenha);
        }

        public void btnAlterar_Click(Object sender, System.EventArgs e)
        {
            strSql = "SELECT senha FROM LOGIN_TB WHERE senha = @Senha";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@Senha", SqlDbType.VarChar).Value = textBox[0].Text;

            String strSenhaAtual;

            try
            {
                sqlCon.Open();

                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                strSenhaAtual = Convert.ToString(dr["senha"]);
                dr.Close();
                alterarSenha();
            }
            catch (Exception exception)
            {
                MessageBox.Show("Senha Incorreta", "Dado inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox[0].Focus();
            }
            finally
            {
                sqlCon.Close();
            }

        }

        private void alterarSenha()
        {
            if (textBox[1].Text.Equals(textBox[2].Text))
            {
                strSql = "UPDATE LOGIN_TB SET senha = @Senha WHERE usuario = @Usuario";
                sqlCon = new SqlConnection(strCon);
                SqlCommand cmd = new SqlCommand(strSql, sqlCon);

                cmd.Parameters.Add("@Senha", SqlDbType.VarChar).Value = textBox[1].Text;
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Senha alterada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão com o banco de dados!", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sqlCon.Close();
                }
            }
            else
            {
                MessageBox.Show("As senhas não coincidem", "Divergência de dados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox[1].Focus();
            }
        }

        public void btnCancelar_Click(Object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
