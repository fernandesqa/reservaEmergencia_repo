﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Drawing;
using System.Windows.Forms;

namespace ControleDeReserva
{
    
    public partial class TelaDeSplash : Form
    {
        //Declaração de variáveis e objetos
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        ProgressBar progressBar = new ProgressBar();

        public TelaDeSplash()
        {
            timer.Start();
            Thread.Sleep(5000);
            InitializeTelaDeSplash();
        }

        public void InitializeTelaDeSplash()
        {
            timer.Interval = 35;
            timer.Enabled = true;
            timer.Tick += new EventHandler(timer_Tick);
           
            progressBar.SetBounds(5, 360, 400, 30);
            progressBar.Name = "progressBarSplash";

            PictureBox pbSplash = new PictureBox();
            pbSplash.Image = new Bitmap(@"Imagens\splash.bmp");
            pbSplash.Size = new Size(735, 435);
            pbSplash.Controls.Add(progressBar);

                        
            Panel pnlSplash = new Panel();
            pnlSplash.Name = "pnlSpash";
            pnlSplash.SetBounds(0, 0, 735, 435);
            pnlSplash.Controls.Add(pbSplash);

            this.Name = "FormTelaDeSplash";
            this.Width = 715;
            this.Height = 398;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.None;
            this.Controls.Add(pnlSplash);
        }

        private void timer_Tick(Object sender, EventArgs e)
        {
            progressBar.Increment(1);
            if (progressBar.Value.Equals(100))
            {
                timer.Stop();
                Thread threadLogin = new Thread(TelaLogin_Open);
                threadLogin.Start();
                this.Close();
            }
        }

        private void TelaLogin_Open()
        {
            Application.Run(new TelaLogin());
        }
    }
}
