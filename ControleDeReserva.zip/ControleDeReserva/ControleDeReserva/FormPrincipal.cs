﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace ControleDeReserva
{
    public partial class FormPrincipal : Form
    {
        //Declaração de variáveis e objetos
        private ToolStrip tlStripMenu;
        private ToolStripButton tlStripButtonPerfil;
        private ToolStripButton tlStripButtonDespesas;
        private ToolStripButton tlStripButtonUpdate;
        private ToolStripButton tlStripButtonExcluir;
        private ToolStripButton tlStripButtonConsulta;
        private ToolStripButton tlStripButtonAplicacao;
        private ToolStripButton tlStripButtonReserva;
        private ToolStripButton tlStripButtonRetirada;
        private ToolStripButton tlStripButtonLogout;

        private Panel pnlTelas;

        private String strUserSession;

        public FormPrincipal(String sessao)
        {
            strUserSession = sessao;
            InitializeComponent();
        }

        public void InitializeComponent()
        {
            //TOOLSTRIP
            this.tlStripMenu = new ToolStrip();
            this.tlStripButtonPerfil = new ToolStripButton();
            this.tlStripButtonDespesas = new ToolStripButton();
            this.tlStripButtonUpdate = new ToolStripButton();
            this.tlStripButtonExcluir = new ToolStripButton();
            this.tlStripButtonConsulta = new ToolStripButton();
            this.tlStripButtonAplicacao = new ToolStripButton();
            this.tlStripButtonReserva = new ToolStripButton();
            this.tlStripButtonRetirada = new ToolStripButton();
            this.tlStripButtonLogout = new ToolStripButton();

            this.tlStripMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.tlStripButtonPerfil, this.tlStripButtonDespesas,
            this.tlStripButtonUpdate, this.tlStripButtonExcluir, this.tlStripButtonConsulta, this.tlStripButtonAplicacao, this.tlStripButtonReserva, this.tlStripButtonRetirada, this.tlStripButtonLogout});
            this.tlStripMenu.Location = new System.Drawing.Point(0, 0);
            this.tlStripMenu.TabIndex = 0;
            this.tlStripMenu.ImageScalingSize = new System.Drawing.Size(70, 70);
            this.tlStripMenu.BackColor = Color.White;

            this.tlStripButtonPerfil.Image = Bitmap.FromFile(@"Imagens\usuario.bmp");
            this.tlStripButtonPerfil.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.tlStripButtonPerfil.Text = "Perfil";
            this.tlStripButtonPerfil.Name = "tlbPerfil";
            this.tlStripButtonPerfil.ImageAlign = ContentAlignment.MiddleLeft;
            this.tlStripButtonPerfil.Margin = new Padding(10, 0, 10, 0);
            this.tlStripButtonPerfil.Click += new EventHandler(tlStripButtonPerfil_Click);

            this.tlStripButtonDespesas.Image = Bitmap.FromFile(@"Imagens\despesas.bmp");
            this.tlStripButtonDespesas.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.tlStripButtonDespesas.Text = "Despesas";
            this.tlStripButtonDespesas.Name = "tlbDespesas";
            this.tlStripButtonDespesas.ImageAlign = ContentAlignment.MiddleLeft;
            this.tlStripButtonDespesas.Margin = new Padding(10, 0, 10, 0);
            this.tlStripButtonDespesas.Click += new EventHandler(tlStripButtonDespesas_click);

            this.tlStripButtonUpdate.Image = Bitmap.FromFile(@"Imagens\update.bmp");
            this.tlStripButtonUpdate.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.tlStripButtonUpdate.Text = "Alterar";
            this.tlStripButtonUpdate.Name = "tlbAlterar";
            this.tlStripButtonUpdate.ImageAlign = ContentAlignment.MiddleLeft;
            this.tlStripButtonUpdate.Margin = new Padding(10, 0, 10, 0);
            this.tlStripButtonUpdate.Click += new EventHandler(tlStripButtonUpdate_Click);

            this.tlStripButtonExcluir.Image = Bitmap.FromFile(@"Imagens\trashCan.bmp");
            this.tlStripButtonExcluir.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.tlStripButtonExcluir.Text = "Excluir";
            this.tlStripButtonExcluir.Name = "tlbExcluir";
            this.tlStripButtonExcluir.ImageAlign = ContentAlignment.MiddleLeft;
            this.tlStripButtonExcluir.Margin = new Padding(10, 0, 10, 0);
            this.tlStripButtonExcluir.Click += new EventHandler(tlStripButtonExcluir_Click);

            this.tlStripButtonConsulta.Image = Bitmap.FromFile(@"Imagens\consultas.bmp");
            this.tlStripButtonConsulta.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.tlStripButtonConsulta.Text = "Consultar";
            this.tlStripButtonConsulta.Name = "tlbConsultar";
            this.tlStripButtonConsulta.ImageAlign = ContentAlignment.MiddleLeft;
            this.tlStripButtonConsulta.Margin = new Padding(10, 0, 10, 0);
            this.tlStripButtonConsulta.Click += new EventHandler(tlStripButtonConsulta_Click);

            this.tlStripButtonAplicacao.Image = Bitmap.FromFile(@"Imagens\aplicacoes.bmp");
            this.tlStripButtonAplicacao.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.tlStripButtonAplicacao.Text = "Aplicar";
            this.tlStripButtonAplicacao.Name = "tlbAplicar";
            this.tlStripButtonAplicacao.ImageAlign = ContentAlignment.MiddleLeft;
            this.tlStripButtonAplicacao.Margin = new Padding(10, 0, 10, 0);
            this.tlStripButtonAplicacao.Click += new EventHandler(tlStripButtonAplicacao_Click);

            this.tlStripButtonReserva.Image = Bitmap.FromFile(@"Imagens\cofre.bmp");
            this.tlStripButtonReserva.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.tlStripButtonReserva.Text = "Reserva";
            this.tlStripButtonReserva.Name = "tlbReserva";
            this.tlStripButtonReserva.ImageAlign = ContentAlignment.MiddleLeft;
            this.tlStripButtonReserva.Margin = new Padding(10, 0, 10, 0);
            this.tlStripButtonReserva.Click += new EventHandler(tlStripButtonReserva_Click);

            this.tlStripButtonRetirada.Image = Bitmap.FromFile(@"Imagens\retirada.bmp");
            this.tlStripButtonRetirada.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.tlStripButtonRetirada.Text = "Retiradas";
            this.tlStripButtonRetirada.Name = "tlbRetiradas";
            this.tlStripButtonRetirada.ImageAlign = ContentAlignment.MiddleLeft;
            this.tlStripButtonRetirada.Margin = new Padding(10, 0, 10, 0);
            this.tlStripButtonRetirada.Click += new EventHandler(tlStripButtonRetirada_Click);

            this.tlStripButtonLogout.Image = Bitmap.FromFile(@"Imagens\logout.bmp");
            this.tlStripButtonLogout.DisplayStyle = ToolStripItemDisplayStyle.Image;
            this.tlStripButtonLogout.Text = "Logout";
            this.tlStripButtonLogout.Name = "tlbLogout";
            this.tlStripButtonLogout.ImageAlign = ContentAlignment.MiddleLeft;
            this.tlStripButtonLogout.Margin = new Padding(10, 0, 10, 0);
            this.tlStripButtonLogout.Click += new EventHandler(tlStripButtonLogout_Click);

            //PAINEL DO MENU
            Panel pnlMenu = new Panel();
            pnlMenu.SetBounds(10, 10, 865, 80);
            pnlMenu.BorderStyle = BorderStyle.FixedSingle;
            pnlMenu.Controls.Add(tlStripMenu);
            pnlMenu.BackColor = Color.White;

            //PAINEL DE TELAS
            pnlTelas = new Panel();
            pnlTelas.SetBounds(10, 100, 865, 450);
            pnlTelas.BorderStyle = BorderStyle.Fixed3D;
            pnlTelas.BackColor = Color.White;

            //FORMULÁRIO
            this.Text = "Sistema de Controle de Reserva de Emergência V1.0";
            this.Icon = new Icon(@"Imagens\iconSystem.ico");
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Width = 900;
            this.Height = 600;
            this.tlStripMenu.ResumeLayout(false);
            this.BackColor = Color.White;
            this.MaximizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Controls.Add(pnlMenu);
            this.Controls.Add(pnlTelas);
        }

        //EVENTO DO BOTÃO PERFIL
        public void tlStripButtonPerfil_Click(Object sender, System.EventArgs e)
        {
            var formPerfil = new TelaDePerfil();
            formPerfil.InitializePerfil(strUserSession);
            pnlTelas.Controls.Add(formPerfil);
            formPerfil.Show();  
        }

        //EVENDO DO BOTÃO DESPESAS
        public void tlStripButtonDespesas_click(Object sender, System.EventArgs e)
        {
            var formDespesas = new TelaDeDespesas();
            formDespesas.InitializeDespesas(strUserSession);
            pnlTelas.Controls.Add(formDespesas);
            formDespesas.Show();
        }

        //EVENTO DO BOTÃO UPDATE
        public void tlStripButtonUpdate_Click(Object sender, System.EventArgs e)
        {
            var formUpdate = new TelaDeUpdates();
            formUpdate.InitializeUpdates(strUserSession);
            pnlTelas.Controls.Add(formUpdate);
            formUpdate.Show();
        }

        //EVENTO DO BOTÃO EXCLUIR
        public void tlStripButtonExcluir_Click(Object sender, System.EventArgs e)
        {
            var formExcluir = new TelaDeExclusoes();
            formExcluir.InitializeExclusoes(strUserSession);
            pnlTelas.Controls.Add(formExcluir);
            formExcluir.Show();
        }

        //EVENTO DO BOTÃO CONSULTA
        public void tlStripButtonConsulta_Click(Object sender, System.EventArgs e)
        {
            var formConsulta = new TelaDeConsultas();
            formConsulta.InitializeConsultas(strUserSession);
            pnlTelas.Controls.Add(formConsulta);
            formConsulta.Show();
        }

        //EVENTO DO BOTÃO APLICAÇÃO
        public void tlStripButtonAplicacao_Click(Object sender, System.EventArgs e)
        {
            var formAplicacao = new TelaDeAplicacoes();
            formAplicacao.InitializeAplicacoes(strUserSession);
            pnlTelas.Controls.Add(formAplicacao);
            formAplicacao.Show();
        }

        //EVENTO DO BOTÃO RESERVA
        public void tlStripButtonReserva_Click(Object sender, System.EventArgs e)
        {
            var formReserva = new TelaReservaDeEmergencia();
            formReserva.InitializeReservaDeEmergencia(strUserSession);
            pnlTelas.Controls.Add(formReserva);
            formReserva.Show();
        }

        //EVENTO DO BOTÃO RETIRADA
        public void tlStripButtonRetirada_Click(Object sender, System.EventArgs e)
        {
            var formRetirada = new TelaDeRetiradas();
            formRetirada.InitializeRetiradas(strUserSession);
            pnlTelas.Controls.Add(formRetirada);
            formRetirada.Show();
        }

        //EVENTO DO BOTÃO LOGOUT
        public void tlStripButtonLogout_Click(Object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Tem certeza que deseja sair?", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result.Equals(DialogResult.Yes))
            {
                Thread threadLogin = new Thread(TelaLogin_Load);
                threadLogin.Start();
                strUserSession = "";
                this.Close();
            }
        }

        private void TelaLogin_Load()
        {
            Application.Run(new TelaLogin());
        }
    }
}
