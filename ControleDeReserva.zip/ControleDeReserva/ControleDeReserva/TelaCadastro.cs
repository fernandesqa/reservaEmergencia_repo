﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class TelaCadastro : Form
    {
        //Declaração de variáveis e objetos
        Panel pnlCadastro;
        Label[] label = new Label[13];
        TextBox[] textBox = new TextBox[8];
        Button[] button = new Button[2];
        String strSenha, strConfSenha, strUser;

        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;

        public void InitializeTelaCadastro()
        {
            //LABEL
            label[0] = new Label();
            label[0].Name = "lblCadastro";
            label[0].Text = "Cadastro de Usuário";
            label[0].Font = new Font(label[0].Name, 18, FontStyle.Bold);
            label[0].SetBounds(5, 5, 300, 50);

            label[1] = new Label();
            label[1].Name = "lblNome";
            label[1].Text = "Nome";
            label[1].SetBounds(5, 100, 60, 20);

            label[2] = new Label();
            label[2].Name = "lblSobrenome";
            label[2].Text = "Sobrenome";
            label[2].SetBounds(5, 160, 65, 20);

            label[3] = new Label();
            label[3].Name = "lblUsuario";
            label[3].Text = "Usuário";
            label[3].SetBounds(5, 220, 60, 20);

            label[4] = new Label();
            label[4].Name = "lblSenha";
            label[4].Text = "Senha";
            label[4].SetBounds(5, 280, 60, 20);

            label[5] = new Label();
            label[5].Name = "lblConfirmSenha";
            label[5].Text = "Confirmar senha";
            label[5].SetBounds(5, 340, 120, 20);

            label[6] = new Label();
            label[6].Name = "lblTempoReserva";
            label[6].Text = "Tempo de Reserva";
            label[6].SetBounds(5, 400, 120, 20);

            label[7] = new Label();
            label[7].Name = "lblPergunta";
            label[7].Text = "Pergunta Secreta";
            label[7].SetBounds(5, 460, 120, 20);

            label[8] = new Label();
            label[8].Name = "lblResposta";
            label[8].Text = "Resposta";
            label[8].SetBounds(5, 520, 120, 20);

            label[9] = new Label();
            label[9].Name = "lblVerifyPass";
            label[9].ForeColor = Color.Red;
            label[9].Font = new Font(label[9].Name, 8);
            label[9].SetBounds(260, 340, 150, 20);

            label[10] = new Label();
            label[10].Name = "lblInfoPergunta";
            label[10].ForeColor = Color.Blue;
            label[10].Font = new Font(label[10].Name, 8);
            label[10].SetBounds(135, 480, 250, 12);

            label[11] = new Label();
            label[11].Name = "lblInfoResposta";
            label[11].ForeColor = Color.Blue;
            label[11].Font = new Font(label[11].Name, 8);
            label[11].SetBounds(135, 540, 250, 12);

            label[12] = new Label();
            label[12].Name = "lblInfoUsuario";
            label[12].ForeColor = Color.Red;
            label[12].Font = new Font(label[12].Name, 8);
            label[12].SetBounds(135, 240, 250, 20);

            //TEXTBOX
            textBox[0] = new TextBox();
            textBox[0].Name = "txtNome";
            textBox[0].MaxLength = 20;
            textBox[0].SetBounds(135, 95, 160, 40);

            textBox[1] = new TextBox();
            textBox[1].Name = "txtSobrenome";
            textBox[1].MaxLength = 80;
            textBox[1].SetBounds(135, 155, 160, 40);

            textBox[2] = new TextBox();
            textBox[2].Name = "txtUsuario";
            textBox[2].MaxLength = 20;
            textBox[2].Leave += txtUsuario_Leave;
            textBox[2].SetBounds(135, 215, 120, 40);

            textBox[3] = new TextBox();
            textBox[3].Name = "txtSenha";
            textBox[3].PasswordChar = '*';
            textBox[3].MaxLength = 30;
            textBox[3].SetBounds(135, 275, 120, 40);

            textBox[4] = new TextBox();
            textBox[4].Name = "txtConfirmSenha";
            textBox[4].PasswordChar = '*';
            textBox[4].MaxLength = 30;
            textBox[4].Leave += txtConfirmSenha_Leave;
            textBox[4].SetBounds(135, 335, 120, 40);

            textBox[5] = new TextBox();
            textBox[5].Name = "txtTempoReserva";
            textBox[5].MaxLength = 2;
            textBox[5].KeyPress += txtTepoReserva_Enter;
            textBox[5].SetBounds(135, 395, 40, 40);

            textBox[6] = new TextBox();
            textBox[6].Name = "txtPergunta";
            textBox[6].MaxLength = 50;
            textBox[6].Enter += txtPergunta_Enter;
            textBox[6].Leave += txtPergunta_Leave;
            textBox[6].SetBounds(135, 455, 160, 40);

            textBox[7] = new TextBox();
            textBox[7].Name = "txtResposta";
            textBox[7].MaxLength = 50;
            textBox[7].Enter += txtResposta_Enter;
            textBox[7].Leave += txtResposta_Leave;
            textBox[7].SetBounds(135, 515, 160, 40);

            //BUTTON
            button[0] = new Button();
            button[0].Name = "btnCadastrar";
            button[0].Text = "Cadastrar";
            button[0].SetBounds(120, 560, 80, 40);
            button[0].Click += new EventHandler(btnEntrar_Click);

            button[1] = new Button();
            button[1].Name = "btnCancelar";
            button[1].Text = "Cancelar";
            button[1].SetBounds(214, 560, 80, 40);
            button[1].Click += new EventHandler(btnCancelar_Click);

            //PANEL
            pnlCadastro = new Panel();
            pnlCadastro.BorderStyle = BorderStyle.FixedSingle;
            pnlCadastro.SetBounds(5, 5, 423, 610);
            pnlCadastro.Controls.Add(label[0]);
            pnlCadastro.Controls.Add(label[1]);
            pnlCadastro.Controls.Add(label[2]);
            pnlCadastro.Controls.Add(label[3]);
            pnlCadastro.Controls.Add(label[4]);
            pnlCadastro.Controls.Add(label[5]);
            pnlCadastro.Controls.Add(label[6]);
            pnlCadastro.Controls.Add(label[7]);
            pnlCadastro.Controls.Add(label[8]);
            pnlCadastro.Controls.Add(label[9]);
            pnlCadastro.Controls.Add(label[10]);
            pnlCadastro.Controls.Add(label[11]);
            pnlCadastro.Controls.Add(label[12]);
            pnlCadastro.Controls.Add(textBox[0]);
            pnlCadastro.Controls.Add(textBox[1]);
            pnlCadastro.Controls.Add(textBox[2]);
            pnlCadastro.Controls.Add(textBox[3]);
            pnlCadastro.Controls.Add(textBox[4]);
            pnlCadastro.Controls.Add(textBox[5]);
            pnlCadastro.Controls.Add(textBox[6]);
            pnlCadastro.Controls.Add(textBox[7]);
            pnlCadastro.Controls.Add(button[0]);
            pnlCadastro.Controls.Add(button[1]);

            this.Text = "Cadastro de Usuário";
            this.Width = 450;
            this.Height = 660;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ControlBox = false;
            this.BackColor = Color.White;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Controls.Add(pnlCadastro);
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        public void txtUsuario_Leave(Object sender, EventArgs e)
        {
            String strUsuario = textBox[2].Text;
            strSql = "SELECT usuario FROM LOGIN_TB WHERE usuario = '"+strUsuario+"'";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            try
            {
                sqlCon.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Columns.Add("usuario", typeof(string));
                dt.Load(dr);

                strUser = dt.Rows[0]["usuario"].ToString();

                if (strUser.Equals(strUsuario))
                {
                    label[12].Text = "Usuário já cadastrado na base de dados!";
                }
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                label[12].Text = "";
                strUser = "";
            }
            finally
            {
                sqlCon.Close();
            }
        }

        public void txtConfirmSenha_Leave(Object sender, EventArgs e)
        {
            strSenha = textBox[3].Text;
            strConfSenha = textBox[4].Text;

            if (!strConfSenha.Equals(strSenha))
            {
                label[9].Text = "As senhas não coincidem";
            }
            else if(strConfSenha.Equals(strSenha))
            {
                label[9].Text = "";
            }
        }

        public void txtTepoReserva_Enter(Object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;

            }
        }

        public void txtPergunta_Enter(Object sender, EventArgs e)
        {
            label[10].Text = "Necessário caso esqueça o usuário ou senha";
        }

        public void txtPergunta_Leave(Object sender, EventArgs e)
        {
            label[10].Text = "";
        }

        public void txtResposta_Enter(Object sender, EventArgs e)
        {
            label[11].Text = "Necessário caso esqueça o usuário ou senha";
        }

        public void txtResposta_Leave(Object sender, EventArgs e)
        {
            label[11].Text = "";
        }

        public void btnEntrar_Click(Object sender, EventArgs e)
        {
            if (textBox[0].Text.Equals("") || textBox[1].Text.Equals("") || textBox[1].Text.Equals("") || textBox[2].Text.Equals("") || textBox[3].Text.Equals("") || textBox[4].Text.Equals("") || textBox[5].Text.Equals("") || textBox[6].Text.Equals("") || textBox[7].Text.Equals(""))
            {
                MessageBox.Show("Todos os campos devem ser preenchidos!", "Alerta!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            } else if (strConfSenha.Equals(strSenha) && !strUser.Equals(textBox[2].Text))
            {
                insertIntoLogin();
                insertIntoPessoa();
                this.Close();
            }
        }

        private void insertIntoLogin()
        {
            strSql = "INSERT INTO LOGIN_TB (usuario, senha) VALUES (@usuario, @senha)";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@usuario", SqlDbType.VarChar).Value = textBox[2].Text;
            cmd.Parameters.Add("@senha", SqlDbType.VarChar).Value = strSenha;

            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                MessageBox.Show("Erro ao conectar com o banco de dados!", "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void insertIntoPessoa()
        {
            strSql = "INSERT INTO PESSOA_PERFIL_TB VALUES (@usuario, @nome, @sobrenome, @tempoReserva, @pergunta, @resposta)";
            sqlCon = new SqlConnection(strCon);
            SqlCommand cmd = new SqlCommand(strSql, sqlCon);

            cmd.Parameters.Add("@usuario", SqlDbType.VarChar).Value = textBox[2].Text;
            cmd.Parameters.Add("@nome", SqlDbType.VarChar).Value = textBox[0].Text;
            cmd.Parameters.Add("@sobrenome", SqlDbType.VarChar).Value = textBox[1].Text;
            cmd.Parameters.Add("@tempoReserva", SqlDbType.Int).Value = Convert.ToInt32(textBox[5].Text);
            cmd.Parameters.Add("@pergunta", SqlDbType.VarChar).Value = textBox[6].Text;
            cmd.Parameters.Add("@resposta", SqlDbType.VarChar).Value = textBox[7].Text;

            try
            {
                sqlCon.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Usuário Cadastrado com sucesso!", "Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {
                MessageBox.Show("Erro ao conectar com o banco de dados!", "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        public void btnCancelar_Click(Object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
