﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace ControleDeReserva
{
    public partial class TelaDeExclusoes : Form
    {
        //Declaração de objetos e variáveis
        Label[] label = new Label[4];
        ComboBoxMes comboBoxMes;
        ComboBoxAno comboBoxAno;
        ComboBoxTipo comboBoxTipo;
        Button[] button = new Button[2];
        String strUserSession;
        ConsultaBanco banco = new ConsultaBanco();
        DataGridView dtGridView = new DataGridView();
        SqlDataAdapter sAdapter;
        DataSet sDs;
        SqlConnection sqlCon = null;
        private static string strCon = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=ReservaDeEmergenciaDb;Data Source=(local)";
        private string strSql = string.Empty;


        public void InitializeExclusoes(String strUserSession)
        {
            //Carrega a variável com os dados do usuário
            this.strUserSession = strUserSession;

            //LABELS
            label[0] = new Label();
            label[0].Name = "lblExclusoes";
            label[0].Text = "Exclusão de dados";
            label[0].Font = new Font(label[0].Name, 18, FontStyle.Bold);
            label[0].SetBounds(5, 5, 350, 50);

            label[1] = new Label();
            label[1].Name = "lblMes";
            label[1].Text = "Mês";
            label[1].SetBounds(5, 60, 30, 20);

            label[2] = new Label();
            label[2].Name = "lblAno";
            label[2].Text = "Ano";
            label[2].SetBounds(220, 60, 30, 20);

            label[3] = new Label();
            label[3].Name = "lblTipo";
            label[3].Text = "Tipo";
            label[3].SetBounds(435, 60, 30, 20);

            //COMBOBOX
            comboBoxMes = new ComboBoxMes();
            comboBoxMes.InitializeComboBoxMes();
            comboBoxMes.SelectedIndexChanged += new EventHandler(comBoBoxMes_SelectedIndexChanged);
            comboBoxMes.SetBounds(50, 55, 150, 80);

            comboBoxAno = new ComboBoxAno();
            comboBoxAno.InitializeComboBoxAno();
            comboBoxAno.SelectedIndexChanged += new EventHandler(comboBoxAno_SelectedIndexChanged);
            comboBoxAno.SetBounds(265, 55, 150, 80);

            comboBoxTipo = new ComboBoxTipo();
            comboBoxTipo.InitializeComboBoxTipo();
            comboBoxTipo.SelectedIndexChanged += new EventHandler(comboBoxTipo_SelectedIndexChanged);
            comboBoxTipo.SetBounds(480, 55, 150, 80);

            //Button
            button[0] = new Button();
            button[0].Name = "btnBuscar";
            button[0].Text = "Buscar";
            button[0].SetBounds(640, 53, 100, 25);
            button[0].Click += new EventHandler(btnBuscar_Click);

            button[1] = new Button();
            button[1].Name = "btnExcluir";
            button[1].Text = "Excluir";
            button[1].Enabled = false;
            button[1].SetBounds(640, 350, 100, 50);
            button[1].Click += new EventHandler(btnExcluir_Click);

            dtGridView.SetBounds(5, 100, 735, 200);

            //Panel
            Panel pnlExclusoes = new Panel();
            pnlExclusoes.BorderStyle = BorderStyle.FixedSingle;
            pnlExclusoes.SetBounds(5, 5, 850, 440);
            pnlExclusoes.Controls.Add(label[0]);
            pnlExclusoes.Controls.Add(label[1]);
            pnlExclusoes.Controls.Add(label[2]);
            pnlExclusoes.Controls.Add(label[3]);
            pnlExclusoes.Controls.Add(comboBoxMes);
            pnlExclusoes.Controls.Add(comboBoxAno);
            pnlExclusoes.Controls.Add(comboBoxTipo);
            pnlExclusoes.Controls.Add(button[0]);
            pnlExclusoes.Controls.Add(button[1]);
            pnlExclusoes.Controls.Add(dtGridView);

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Icon = new Icon(@"Imagens\iconeTrashCan.ico");
            this.Text = "Exclusão";
            this.TopLevel = false;
            this.Width = 765;
            this.Height = 450;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.WindowState = FormWindowState.Maximized;
            this.Controls.Add(pnlExclusoes);
        }

        public void comBoBoxMes_SelectedIndexChanged(Object sender, EventArgs e)
        {
            button[1].Enabled = false;
        }

        public void comboBoxAno_SelectedIndexChanged(Object sender, EventArgs e)
        {
            button[1].Enabled = false;
        }

        public void comboBoxTipo_SelectedIndexChanged(Object sender, EventArgs e)
        {
            button[1].Enabled = false;
        }

        public void btnBuscar_Click(Object sender, System.EventArgs e)
        {
            if (comboBoxMes.Text.ToLower().Equals("selecione") || comboBoxAno.Text.ToLower().Equals("selecione") || comboBoxTipo.Text.ToLower().Equals("selecione"))
            {
                MessageBox.Show("Você deve selecionar o mês, o ano e o tipo", "Dados obrigatórios", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (comboBoxTipo.Text.ToLower().Equals("despesas"))
            {
                strSql = "SELECT moradia, internetTvFixo, luz, cartaoDeCredito, educacao, supermercado, lazer, saude, contador, transporte, inss, outros FROM DESPESAS_TB WHERE usuario = '"+strUserSession+"' AND id_mes = '"+banco.GetMonthId(comboBoxMes.Text)+"' AND id_ano = '"+banco.GetYearId(comboBoxAno.Text)+"'";
                sqlCon = new SqlConnection(strCon);
                SqlCommand cmd = new SqlCommand(strSql, sqlCon);

                try
                {
                    if (banco.checkDataTable(strSql))
                    {
                        sqlCon.Open();
                        cmd.CommandType = CommandType.Text;
                        sAdapter = new SqlDataAdapter(cmd);
                        sDs = new DataSet();
                        dtGridView.ReadOnly = true;
                        sAdapter.Fill(sDs, "Despesas");
                        dtGridView.DataSource = sDs.Tables["Despesas"];
                        button[1].Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Não há dados de "+comboBoxTipo.Text+" cadastrados em "+comboBoxMes.Text+ " de "+comboBoxAno.Text, "Dados não encontrados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na Conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sqlCon.Close();
                }
            } else if (comboBoxTipo.Text.ToLower().Equals("aplicações"))
            {
                strSql = "SELECT T.aplicacao_nome, A.valor FROM TIPO_APLICACOES_TB T INNER JOIN APLICACOES_FINANCEIRAS_TB A ON T.id_aplicacao = A.id_aplicacao AND A.usuario = '"+strUserSession+"' AND A.id_mes = '"+ banco.GetMonthId(comboBoxMes.Text) + "' AND A.id_ano = '"+ banco.GetYearId(comboBoxAno.Text) + "'";
                sqlCon = new SqlConnection(strCon);
                SqlCommand cmd = new SqlCommand(strSql, sqlCon);

                try
                {
                    if (banco.checkDataTable(strSql))
                    {
                        sqlCon.Open();
                        cmd.CommandType = CommandType.Text;
                        sAdapter = new SqlDataAdapter(cmd);
                        sDs = new DataSet();
                        dtGridView.ReadOnly = true;
                        sAdapter.Fill(sDs, "Aplicacoes");
                        dtGridView.DataSource = sDs.Tables["Aplicacoes"];
                        button[1].Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Não há dados de " + comboBoxTipo.Text + " cadastrados em " + comboBoxMes.Text + " de " + comboBoxAno.Text, "Dados não encontrados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                   
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na Conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sqlCon.Close();
                }
            } else if (comboBoxTipo.Text.ToLower().Equals("retiradas"))
            {
                strSql = "SELECT dia, horario, valor FROM RETIRADAS_TB WHERE mes ='"+comboBoxMes.Text+"' AND ano ='"+ comboBoxAno.Text+"' AND usuario ='"+strUserSession+"'";
                sqlCon = new SqlConnection(strCon);
                SqlCommand cmd = new SqlCommand(strSql, sqlCon);

                try
                {
                    if (banco.checkDataTable(strSql))
                    {
                        sqlCon.Open();
                        cmd.CommandType = CommandType.Text;
                        sAdapter = new SqlDataAdapter(cmd);
                        sDs = new DataSet();
                        dtGridView.ReadOnly = true;
                        sAdapter.Fill(sDs, "Retiradas");
                        dtGridView.DataSource = sDs.Tables["Retiradas"];
                        button[1].Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Não há dados de " + comboBoxTipo.Text + " cadastrados em " + comboBoxMes.Text + " de " + comboBoxAno.Text, "Dados não encontrados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na Conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sqlCon.Close();
                }
            }
        }

        public void btnExcluir_Click(Object sender, EventArgs e)
        {
            DialogResult result =  MessageBox.Show("Tem certeza que deseja excluir os dados de " + comboBoxTipo.Text + "?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result.Equals(DialogResult.Yes))
            {
                excluirDados();
                button[1].Enabled = false;
            }
        }

        private void excluirDados()
        {
            if (comboBoxTipo.Text.ToLower().Equals("despesas") || comboBoxTipo.Text.ToLower().Equals("aplicações"))
            {
                if (comboBoxTipo.Text.ToLower().Equals("despesas"))
                {
                    strSql = "DELETE DESPESAS_TB WHERE usuario = @Usuario AND id_mes = @idMes AND id_ano = @idAno";
                }
                else
                {
                    strSql = "DELETE APLICACOES_FINANCEIRAS_TB WHERE usuario = @Usuario AND id_mes = @idMes AND id_ano = @idAno";
                }

                sqlCon = new SqlConnection(strCon);
                SqlCommand cmd = new SqlCommand(strSql, sqlCon);

                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;
                cmd.Parameters.Add("@idMes", SqlDbType.VarChar).Value = banco.GetMonthId(comboBoxMes.Text);
                cmd.Parameters.Add("@idAno", SqlDbType.VarChar).Value = banco.GetYearId(comboBoxAno.Text);

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Dados excluídos com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception e)
                {
                    MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sqlCon.Close();
                }
            } else if (comboBoxTipo.Text.ToLower().Equals("retiradas"))
            {
                strSql = "DELETE RETIRADAS_TB WHERE mes = @Mes AND ano = @Ano AND usuario = @Usuario";
                sqlCon = new SqlConnection(strCon);
                SqlCommand cmd = new SqlCommand(strSql, sqlCon);

                cmd.Parameters.Add("@Mes", SqlDbType.VarChar).Value = comboBoxMes.Text;
                cmd.Parameters.Add("@Ano", SqlDbType.VarChar).Value = comboBoxAno.Text;
                cmd.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = strUserSession;

                try
                {
                    sqlCon.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Dados excluídos com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão com o banco de dados", "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sqlCon.Close();
                }
            }
            
        }
    }
}
