﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControleDeReserva
{
    public class Session
    {
        String strUserSession;

        public String getUserSession()
        {
            return strUserSession;
        }

        public void setUserSession(String strUserSession)
        {
            this.strUserSession = strUserSession;
        }
    }
}
